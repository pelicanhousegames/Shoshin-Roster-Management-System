<?php
if (!defined('ABSPATH')) {
    exit;
}

class SSB_Settings {

    const OPTION_WAREHOUSES = 'ssb_warehouses';
    const OPTION_VENDORS    = 'ssb_vendors';

        /**
         * Initialize settings hooks.
         */
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'register_settings_page'));
        add_action('admin_menu', array(__CLASS__, 'register_records_pages'), 20);
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('admin_post_ssb_save_warehouse', array(__CLASS__, 'handle_save_warehouse'));
        add_action('admin_post_ssb_save_vendor', array(__CLASS__, 'handle_save_vendor'));
        add_action('admin_post_ssb_toggle_warehouse_active', array(__CLASS__, 'handle_toggle_warehouse_active'));
        add_action('admin_post_ssb_toggle_vendor_active', array(__CLASS__, 'handle_toggle_vendor_active'));
        add_action('admin_post_ssb_delete_warehouse', array(__CLASS__, 'handle_delete_warehouse'));
        add_action('admin_post_ssb_delete_vendor', array(__CLASS__, 'handle_delete_vendor'));
        add_filter('plugin_action_links_' . SSB_BASENAME, array(__CLASS__, 'add_plugin_action_links'));
    }

        /**
         * Returns whether the bridge should use Shippo test mode.
         *
         * Resolution order:
         * 1. Manual override option (future-proofed)
         * 2. Detected Shippo plugin settings
         * 3. Default false (live)
         *
         * @return bool
         */
        public static function is_test_mode() {
            $manual = get_option('ssb_shippo_mode', '');
            if ($manual === 'test') {
                return true;
            }
            if ($manual === 'live') {
                return false;
            }

            $detected = self::detect_shippo_mode_from_existing_plugin();
            if ($detected !== null) {
                return (bool) $detected;
            }

            return false;
        }

        /**
         * Return the active Shippo API token.
         *
         * Resolution order:
         * 1. Manual override options (future-proofed)
         * 2. Existing Shippo plugin settings
         *
         * @return string
         */
        public static function get_shippo_token() {
            $is_test = self::is_test_mode();

            $manual_live = trim((string) get_option('ssb_shippo_live_token', ''));
            $manual_test = trim((string) get_option('ssb_shippo_test_token', ''));

            if ($is_test && $manual_test !== '') {
                return $manual_test;
            }

            if (!$is_test && $manual_live !== '') {
                return $manual_live;
            }

            $detected = self::detect_shippo_tokens_from_existing_plugin();

            if ($is_test && !empty($detected['test'])) {
                return (string) $detected['test'];
            }

            if (!$is_test && !empty($detected['live'])) {
                return (string) $detected['live'];
            }

            return '';
        }

        /**
         * Return the store origin from Woo settings.
         *
         * @return array
         */
        public static function get_origin_address() {
            $settings = self::get_shipper_settings();
            /*$adjustments = self::get_rate_adjustment_settings();*/
            $country = strtoupper(trim((string) $settings['country']));
            $phone   = self::normalize_phone($settings['phone'], $country);

            return array(
                'name'     => (string) $settings['name'],
                'company'  => (string) $settings['company'],
                'street1'  => (string) $settings['street1'],
                'street2'  => (string) $settings['street2'],
                'city'     => (string) $settings['city'],
                'state'    => (string) $settings['state'],
                'zip'      => (string) $settings['zip'],
                'country'  => $country,
                'phone'    => $phone,
                'email'    => (string) $settings['email'],
            );
        }

            /**
         * Normalize phone values for carrier-facing payloads.
         *
         * @param string $phone
         * @param string $country
         * @return string
         */
        protected static function normalize_phone($phone, $country = '') {
            $phone   = trim((string) $phone);
            $country = strtoupper(trim((string) $country));

            if ($phone === '') {
                return '';
            }

            $digits = preg_replace('/\D+/', '', $phone);

            if ($country === 'US' && strlen($digits) === 11 && strpos($digits, '1') === 0) {
                $digits = substr($digits, 1);
            }

            return $digits;
        }

        protected static function normalize_money_setting($value) {
        $value = is_scalar($value) ? (string) $value : '';
        $value = trim($value);

        if ($value === '') {
            return '0.00';
        }

        $value = str_replace(',', '', $value);

        if (!is_numeric($value)) {
            return '0.00';
        }

        $value = (float) $value;

        if ($value < 0) {
            $value = 0;
        }

        return number_format($value, 2, '.', '');
    }

            /**
         * Register plugin settings page under Settings.
         *
         * @return void
         */
        public static function register_settings_page() {
            add_options_page(
                'Shoshin Shippo Bridge',
                'Shoshin Shippo Bridge',
                'manage_woocommerce',
                'ssb-settings',
                array(__CLASS__, 'render_settings_page')
            );
        }

            public static function register_records_pages() {
        add_menu_page(
            'Shippo',
            'Shippo',
            'manage_woocommerce',
            'ssb-warehouses',
            array(__CLASS__, 'render_warehouses_page'),
            'dashicons-location-alt',
            56
        );

        add_submenu_page(
            'ssb-warehouses',
            'Warehouses',
            'Warehouses',
            'manage_woocommerce',
            'ssb-warehouses',
            array(__CLASS__, 'render_warehouses_page')
        );

        add_submenu_page(
            'ssb-warehouses',
            'Vendors',
            'Vendors',
            'manage_woocommerce',
            'ssb-vendors',
            array(__CLASS__, 'render_vendors_page')
        );
    }

    protected static function get_warehouses() {
        $rows = get_option(self::OPTION_WAREHOUSES, array());
        return is_array($rows) ? array_values($rows) : array();
    }

    protected static function get_vendors() {
        $rows = get_option(self::OPTION_VENDORS, array());
        return is_array($rows) ? array_values($rows) : array();
    }

    protected static function get_next_sequential_code($prefix, array $rows) {
        $max = 0;

        foreach ($rows as $row) {
            $code = isset($row['code']) ? (string) $row['code'] : '';
            if (preg_match('/^' . preg_quote($prefix, '/') . '(\d+)$/', $code, $matches)) {
                $num = (int) $matches[1];
                if ($num > $max) {
                    $max = $num;
                }
            }
        }

        if ($max < 1) {
            return $prefix . '1';
        }

        return $prefix . ($max + 1);
    }

    protected static function sanitize_record_flag($value) {
        return !empty($value) && (string) $value === '1' ? '1' : '0';
    }

        protected static function find_record_by_code(array $rows, $code) {
        foreach ($rows as $index => $row) {
            if (!empty($row['code']) && (string) $row['code'] === (string) $code) {
                return array(
                    'index'  => $index,
                    'record' => $row,
                );
            }
        }

        return null;
    }

    protected static function get_admin_page_url($slug, array $args = array()) {
        $args = array_merge(array('page' => $slug), $args);
        return add_query_arg($args, admin_url('admin.php'));
    }

    protected static function render_row_action_link($action, $label, $args = array(), $class = '') {
        $url = wp_nonce_url(
            add_query_arg($args, admin_url('admin-post.php?action=' . $action)),
            $action
        );

        return '<a class="' . esc_attr($class) . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }

    protected static function sanitize_warehouse_record($input, $code) {
        $input = is_array($input) ? $input : array();

        return array(
            'code'         => sanitize_text_field($code),
            'active'       => self::sanitize_record_flag($input['active'] ?? '0'),
            'name'         => sanitize_text_field($input['name'] ?? ''),
            'address1'     => sanitize_text_field($input['address1'] ?? ''),
            'address2'     => sanitize_text_field($input['address2'] ?? ''),
            'city'         => sanitize_text_field($input['city'] ?? ''),
            'state'        => sanitize_text_field($input['state'] ?? ''),
            'postal_code'  => sanitize_text_field($input['postal_code'] ?? ''),
            'country'      => strtoupper(preg_replace('/[^A-Z]/', '', (string) ($input['country'] ?? ''))),
            'phone'        => sanitize_text_field($input['phone'] ?? ''),
            'email'        => sanitize_email($input['email'] ?? ''),
        );
    }

    protected static function sanitize_vendor_record($input, $code) {
        $input = is_array($input) ? $input : array();

        return array(
            'code'         => sanitize_text_field($code),
            'active'       => self::sanitize_record_flag($input['active'] ?? '0'),
            'company_name' => sanitize_text_field($input['company_name'] ?? ''),
            'contact'      => sanitize_text_field($input['contact'] ?? ''),
            'address1'     => sanitize_text_field($input['address1'] ?? ''),
            'address2'     => sanitize_text_field($input['address2'] ?? ''),
            'city'         => sanitize_text_field($input['city'] ?? ''),
            'state'        => sanitize_text_field($input['state'] ?? ''),
            'postal_code'  => sanitize_text_field($input['postal_code'] ?? ''),
            'country'      => strtoupper(preg_replace('/[^A-Z]/', '', (string) ($input['country'] ?? ''))),
            'phone'        => sanitize_text_field($input['phone'] ?? ''),
            'email'        => sanitize_email($input['email'] ?? ''),
            'image_id'     => absint($input['image_id'] ?? 0),
        );
    }

    public static function handle_save_warehouse() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_save_warehouse');

        $rows = self::get_warehouses();
        $edit_code = isset($_POST['edit_code']) ? sanitize_text_field($_POST['edit_code']) : '';

        if ($edit_code !== '') {
            $found = self::find_record_by_code($rows, $edit_code);

            if (!$found) {
                wp_safe_redirect(admin_url('admin.php?page=ssb-warehouses'));
                exit;
            }

            $existing = $found['record'];
            $record = self::sanitize_warehouse_record($_POST['warehouse'] ?? array(), $existing['code']);
            $record['active'] = isset($existing['active']) ? $existing['active'] : '0';
            $rows[$found['index']] = $record;
        } else {
            $code = self::get_next_sequential_code('warehouse_', $rows);
            $record = self::sanitize_warehouse_record($_POST['warehouse'] ?? array(), $code);
            $record['active'] = '0';
            $rows[] = $record;
        }

        update_option(self::OPTION_WAREHOUSES, array_values($rows), false);

        wp_safe_redirect(admin_url('admin.php?page=ssb-warehouses'));
        exit;
    }

    public static function handle_save_vendor() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_save_vendor');

        $rows = self::get_vendors();
        $edit_code = isset($_POST['edit_code']) ? sanitize_text_field($_POST['edit_code']) : '';

        if ($edit_code !== '') {
            $found = self::find_record_by_code($rows, $edit_code);

            if (!$found) {
                wp_safe_redirect(admin_url('admin.php?page=ssb-vendors'));
                exit;
            }

            $existing = $found['record'];
            $record = self::sanitize_vendor_record($_POST['vendor'] ?? array(), $existing['code']);
            $record['active'] = isset($existing['active']) ? $existing['active'] : '0';
            $rows[$found['index']] = $record;
        } else {
            $code = self::get_next_sequential_code('vendor_', $rows);
            $record = self::sanitize_vendor_record($_POST['vendor'] ?? array(), $code);
            $record['active'] = '0';
            $rows[] = $record;
        }

        update_option(self::OPTION_VENDORS, array_values($rows), false);

        wp_safe_redirect(admin_url('admin.php?page=ssb-vendors'));
        exit;
    }

        public static function handle_toggle_warehouse_active() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_toggle_warehouse_active');

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $rows = self::get_warehouses();
        $found = self::find_record_by_code($rows, $code);

        if ($found) {
            $rows[$found['index']]['active'] = (!empty($rows[$found['index']]['active']) && $rows[$found['index']]['active'] === '1') ? '0' : '1';
            update_option(self::OPTION_WAREHOUSES, array_values($rows), false);
        }

        wp_safe_redirect(admin_url('admin.php?page=ssb-warehouses'));
        exit;
    }

    public static function handle_toggle_vendor_active() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_toggle_vendor_active');

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $rows = self::get_vendors();
        $found = self::find_record_by_code($rows, $code);

        if ($found) {
            $rows[$found['index']]['active'] = (!empty($rows[$found['index']]['active']) && $rows[$found['index']]['active'] === '1') ? '0' : '1';
            update_option(self::OPTION_VENDORS, array_values($rows), false);
        }

        wp_safe_redirect(admin_url('admin.php?page=ssb-vendors'));
        exit;
    }

    public static function handle_delete_warehouse() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_delete_warehouse');

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $rows = self::get_warehouses();

        $rows = array_values(array_filter($rows, function($row) use ($code) {
            return empty($row['code']) || (string) $row['code'] !== (string) $code;
        }));

        update_option(self::OPTION_WAREHOUSES, $rows, false);

        wp_safe_redirect(admin_url('admin.php?page=ssb-warehouses'));
        exit;
    }

    public static function handle_delete_vendor() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_delete_vendor');

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $rows = self::get_vendors();

        $rows = array_values(array_filter($rows, function($row) use ($code) {
            return empty($row['code']) || (string) $row['code'] !== (string) $code;
        }));

        update_option(self::OPTION_VENDORS, $rows, false);

        wp_safe_redirect(admin_url('admin.php?page=ssb-vendors'));
        exit;
    }

    public static function render_warehouses_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $rows = self::get_warehouses();
        $edit_code = isset($_GET['edit']) ? sanitize_text_field($_GET['edit']) : '';
        $editing = $edit_code !== '' ? self::find_record_by_code($rows, $edit_code) : null;
        $record = $editing ? $editing['record'] : array(
            'name'        => '',
            'address1'    => '',
            'address2'    => '',
            'city'        => '',
            'state'       => '',
            'postal_code' => '',
            'country'     => 'US',
            'phone'       => '',
            'email'       => '',
        );
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Warehouses</h1>
            <hr class="wp-header-end">

            <div class="notice notice-info inline">
                <p><strong>Main Warehouse</strong> is sourced from WooCommerce store settings.</p>
            </div>

            <div style="display:grid; grid-template-columns: 34% 1fr; gap: 24px; align-items:start;">
                <div>
                    <h2><?php echo $editing ? 'Edit Warehouse' : 'Add New Warehouse'; ?></h2>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="ssb_save_warehouse">
                        <?php wp_nonce_field('ssb_save_warehouse'); ?>

                        <?php if ($editing) : ?>
                            <input type="hidden" name="edit_code" value="<?php echo esc_attr($record['code']); ?>">
                        <?php endif; ?>

                        <table class="form-table" role="presentation">
                            <tbody>
                                <tr>
                                    <th scope="row"><label for="warehouse_name">Location Name</label></th>
                                    <td><input type="text" id="warehouse_name" name="warehouse[name]" class="regular-text" value="<?php echo esc_attr($record['name'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_address1">Address1</label></th>
                                    <td><input type="text" id="warehouse_address1" name="warehouse[address1]" class="regular-text" value="<?php echo esc_attr($record['address1'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_address2">Address2</label></th>
                                    <td><input type="text" id="warehouse_address2" name="warehouse[address2]" class="regular-text" value="<?php echo esc_attr($record['address2'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_city">City</label></th>
                                    <td><input type="text" id="warehouse_city" name="warehouse[city]" class="regular-text" value="<?php echo esc_attr($record['city'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_state">State</label></th>
                                    <td><input type="text" id="warehouse_state" name="warehouse[state]" class="regular-text" value="<?php echo esc_attr($record['state'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_postal_code">Postal Code</label></th>
                                    <td><input type="text" id="warehouse_postal_code" name="warehouse[postal_code]" class="regular-text" value="<?php echo esc_attr($record['postal_code'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_country">Country</label></th>
                                    <td><input type="text" id="warehouse_country" name="warehouse[country]" class="regular-text" maxlength="2" value="<?php echo esc_attr($record['country'] ?? 'US'); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_phone">Phone</label></th>
                                    <td><input type="text" id="warehouse_phone" name="warehouse[phone]" class="regular-text" value="<?php echo esc_attr($record['phone'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_email">Email</label></th>
                                    <td><input type="email" id="warehouse_email" name="warehouse[email]" class="regular-text" value="<?php echo esc_attr($record['email'] ?? ''); ?>"></td>
                                </tr>
                            </tbody>
                        </table>

                        <?php submit_button($editing ? 'Save Warehouse' : 'Add New Warehouse'); ?>
                    </form>
                </div>

                <div>
                    <table class="widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Location Name</th>
                                <th>City</th>
                                <th>State</th>
                                <th style="width:90px;">Active</th>
                                <th style="width:140px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($rows)) : ?>
                                <tr>
                                    <td colspan="5">No warehouses found.</td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($rows as $row) : ?>
                                    <tr>
                                        <td><?php echo esc_html($row['name'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['city'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['state'] ?? ''); ?></td>
                                        <td>
                                            <?php
                                            echo self::render_row_action_link(
                                                'ssb_toggle_warehouse_active',
                                                (!empty($row['active']) && $row['active'] === '1') ? 'Active' : 'Inactive',
                                                array('code' => $row['code']),
                                                (!empty($row['active']) && $row['active'] === '1') ? 'button-link' : 'button-link-delete'
                                            );
                                            ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url(self::get_admin_page_url('ssb-warehouses', array('edit' => $row['code']))); ?>">Edit</a>
                                            |
                                            <?php
                                            echo self::render_row_action_link(
                                                'ssb_delete_warehouse',
                                                'Delete',
                                                array('code' => $row['code']),
                                                'submitdelete'
                                            );
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    public static function render_vendors_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $rows = self::get_vendors();
        $edit_code = isset($_GET['edit']) ? sanitize_text_field($_GET['edit']) : '';
        $editing = $edit_code !== '' ? self::find_record_by_code($rows, $edit_code) : null;
        $record = $editing ? $editing['record'] : array(
            'company_name' => '',
            'contact'      => '',
            'address1'     => '',
            'address2'     => '',
            'city'         => '',
            'state'        => '',
            'postal_code'  => '',
            'country'      => 'US',
            'phone'        => '',
            'email'        => '',
            'image_id'     => 0,
        );
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Vendors</h1>
            <hr class="wp-header-end">

            <div style="display:grid; grid-template-columns: 34% 1fr; gap: 24px; align-items:start;">
                <div>
                    <h2><?php echo $editing ? 'Edit Vendor' : 'Add New Vendor'; ?></h2>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="ssb_save_vendor">
                        <?php wp_nonce_field('ssb_save_vendor'); ?>

                        <?php if ($editing) : ?>
                            <input type="hidden" name="edit_code" value="<?php echo esc_attr($record['code']); ?>">
                        <?php endif; ?>

                        <table class="form-table" role="presentation">
                            <tbody>
                                <tr>
                                    <th scope="row"><label for="vendor_company_name">Company Name</label></th>
                                    <td><input type="text" id="vendor_company_name" name="vendor[company_name]" class="regular-text" value="<?php echo esc_attr($record['company_name'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_contact">Contact</label></th>
                                    <td><input type="text" id="vendor_contact" name="vendor[contact]" class="regular-text" value="<?php echo esc_attr($record['contact'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_address1">Address1</label></th>
                                    <td><input type="text" id="vendor_address1" name="vendor[address1]" class="regular-text" value="<?php echo esc_attr($record['address1'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_address2">Address2</label></th>
                                    <td><input type="text" id="vendor_address2" name="vendor[address2]" class="regular-text" value="<?php echo esc_attr($record['address2'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_city">City</label></th>
                                    <td><input type="text" id="vendor_city" name="vendor[city]" class="regular-text" value="<?php echo esc_attr($record['city'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_state">State</label></th>
                                    <td><input type="text" id="vendor_state" name="vendor[state]" class="regular-text" value="<?php echo esc_attr($record['state'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_postal_code">Postal Code</label></th>
                                    <td><input type="text" id="vendor_postal_code" name="vendor[postal_code]" class="regular-text" value="<?php echo esc_attr($record['postal_code'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_country">Country</label></th>
                                    <td><input type="text" id="vendor_country" name="vendor[country]" class="regular-text" maxlength="2" value="<?php echo esc_attr($record['country'] ?? 'US'); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_phone">Phone</label></th>
                                    <td><input type="text" id="vendor_phone" name="vendor[phone]" class="regular-text" value="<?php echo esc_attr($record['phone'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_email">Email</label></th>
                                    <td><input type="email" id="vendor_email" name="vendor[email]" class="regular-text" value="<?php echo esc_attr($record['email'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_image_id">Select Image</label></th>
                                    <td><input type="number" id="vendor_image_id" name="vendor[image_id]" class="regular-text" min="0" value="<?php echo esc_attr($record['image_id'] ?? 0); ?>"></td>
                                </tr>
                            </tbody>
                        </table>

                        <?php submit_button($editing ? 'Save Vendor' : 'Add New Vendor'); ?>
                    </form>
                </div>

                <div>
                    <table class="widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Company Name</th>
                                <th>Contact</th>
                                <th>City</th>
                                <th>State</th>
                                <th style="width:90px;">Active</th>
                                <th style="width:140px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($rows)) : ?>
                                <tr>
                                    <td colspan="6">No vendors found.</td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($rows as $row) : ?>
                                    <tr>
                                        <td><?php echo esc_html($row['company_name'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['contact'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['city'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['state'] ?? ''); ?></td>
                                        <td>
                                            <?php
                                            echo self::render_row_action_link(
                                                'ssb_toggle_vendor_active',
                                                (!empty($row['active']) && $row['active'] === '1') ? 'Active' : 'Inactive',
                                                array('code' => $row['code']),
                                                (!empty($row['active']) && $row['active'] === '1') ? 'button-link' : 'button-link-delete'
                                            );
                                            ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url(self::get_admin_page_url('ssb-vendors', array('edit' => $row['code']))); ?>">Edit</a>
                                            |
                                            <?php
                                            echo self::render_row_action_link(
                                                'ssb_delete_vendor',
                                                'Delete',
                                                array('code' => $row['code']),
                                                'submitdelete'
                                            );
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

        /**
         * Register plugin settings.
         *
         * @return void
         */
    public static function register_settings() {
        register_setting(
            'ssb_settings_group',
            'ssb_shipper_origin',
            array(
                'type'              => 'array',
                'sanitize_callback' => array(__CLASS__, 'sanitize_shipper_origin_settings'),
                'default'           => array(),
            )
        );

        register_setting(
            'ssb_settings_group',
            'ssb_enable_rate_cache',
            array(
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default'           => 'yes',
            )
        );

        register_setting('ssb_settings_group', 'ssb_usps_signature_required', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '3.95',
        ));

        register_setting('ssb_settings_group', 'ssb_usps_adult_signature_required', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '9.70',
        ));

        register_setting('ssb_settings_group', 'ssb_usps_insurance', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '0.00',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_signature_required', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '6.25',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_adult_signature_required', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '7.50',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_carbon_neutral', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '0.05',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_saturday_delivery', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '16.00',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_additional_handling', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '14.25',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_insurance', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '0.00',
        ));

        register_setting(
            'ssb_settings_group',
            'ssb_enable_multipackage_mode',
            array(
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default'           => 'no',
            )
        );

        register_setting('ssb_settings_group', 'ssb_disable_alcohol');
        register_setting('ssb_settings_group', 'ssb_disable_dry_ice');
        register_setting('ssb_settings_group', 'ssb_disable_hazmat');
        register_setting('ssb_settings_group', self::OPTION_WAREHOUSES);
        register_setting('ssb_settings_group', self::OPTION_VENDORS);
    }

    /**
     * Add Settings link on Plugins screen.
     *
     * @param array $links
     * @return array
     */
    public static function add_plugin_action_links($links) {
        $settings_link = '<a href="' . esc_url(admin_url('options-general.php?page=ssb-settings')) . '">Settings</a>';
        array_unshift($links, $settings_link);
        return $links;
    }

    /**
     * Render settings page.
     *
     * @return void
     */
    public static function render_settings_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $settings = self::get_shipper_settings();
        $adjustments = self::get_rate_adjustment_settings();

?>
        <div class="wrap">
            <h1>Shoshin Shippo Bridge</h1>
            <p>Configure the shipper / origin address used for Shippo label creation.</p>

            <form method="post" action="options.php">
                <?php settings_fields('ssb_settings_group'); ?>

                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_name">Sender name</label></th>
                            <td><input name="ssb_shipper_origin[name]" type="text" id="ssb_shipper_origin_name" class="regular-text" value="<?php echo esc_attr($settings['name']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_company">Company</label></th>
                            <td><input name="ssb_shipper_origin[company]" type="text" id="ssb_shipper_origin_company" class="regular-text" value="<?php echo esc_attr($settings['company']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_street1">Street address 1</label></th>
                            <td><input name="ssb_shipper_origin[street1]" type="text" id="ssb_shipper_origin_street1" class="regular-text" value="<?php echo esc_attr($settings['street1']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_street2">Street address 2</label></th>
                            <td><input name="ssb_shipper_origin[street2]" type="text" id="ssb_shipper_origin_street2" class="regular-text" value="<?php echo esc_attr($settings['street2']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_city">City</label></th>
                            <td><input name="ssb_shipper_origin[city]" type="text" id="ssb_shipper_origin_city" class="regular-text" value="<?php echo esc_attr($settings['city']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_state">State / Province</label></th>
                            <td><input name="ssb_shipper_origin[state]" type="text" id="ssb_shipper_origin_state" class="regular-text" value="<?php echo esc_attr($settings['state']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_zip">ZIP / Postal code</label></th>
                            <td><input name="ssb_shipper_origin[zip]" type="text" id="ssb_shipper_origin_zip" class="regular-text" value="<?php echo esc_attr($settings['zip']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_country">Country code</label></th>
                            <td>
                                <input name="ssb_shipper_origin[country]" type="text" id="ssb_shipper_origin_country" class="regular-text" maxlength="2" value="<?php echo esc_attr($settings['country']); ?>">
                                <p class="description">Use a 2-letter ISO country code, such as US.</p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_phone">Phone</label></th>
                            <td>
                                <input name="ssb_shipper_origin[phone]" type="text" id="ssb_shipper_origin_phone" class="regular-text" value="<?php echo esc_attr($settings['phone']); ?>">
                                <p class="description">For USPS/UPS, enter a real origin phone. Digits-only is preferred.</p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_email">Email</label></th>
                            <td><input name="ssb_shipper_origin[email]" type="email" id="ssb_shipper_origin_email" class="regular-text" value="<?php echo esc_attr($settings['email']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row">Admin Rate Cache</th>
                            <td>
                                <label for="ssb_enable_rate_cache">
                                    <input type="checkbox"
                                        id="ssb_enable_rate_cache"
                                        name="ssb_enable_rate_cache"
                                        value="yes"
                                        <?php checked(get_option('ssb_enable_rate_cache', 'yes'), 'yes'); ?>>
                                    Enable 60-second caching for admin "Fetch Rates" requests
                                </label>
                                <p class="description">
                                    Reduces UPS throttling during admin use. Disable for debugging live rate behavior.
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">WooCommerce Multi-Package Mode</th>
                            <td>
                                <label for="ssb_enable_multipackage_mode">
                                    <input type="checkbox"
                                        id="ssb_enable_multipackage_mode"
                                        name="ssb_enable_multipackage_mode"
                                        value="yes"
                                        <?php checked(get_option('ssb_enable_multipackage_mode', 'no'), 'yes'); ?>>
                                    Enable Multi-Package Mode
                                </label>
                                <p class="description">
                                    When enabled, the plugin will use multi-package shipping logic for storefront package splitting and future warehouse multi-piece fulfillment behavior. Leave disabled to preserve the current single-package baseline.
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">Shipment Option Controls</th>
                            <td>
                                <label>
                                    <input type="checkbox"
                                        name="ssb_disable_alcohol"
                                        value="1"
                                        <?php checked(get_option('ssb_disable_alcohol', '0'), '1'); ?>>
                                    Disable Alcohol
                                </label>
                                <br>

                                <label>
                                    <input type="checkbox"
                                        name="ssb_disable_dry_ice"
                                        value="1"
                                        <?php checked(get_option('ssb_disable_dry_ice', '0'), '1'); ?>>
                                    Disable Dry Ice
                                </label>
                                <br>

                                <label>
                                    <input type="checkbox"
                                        name="ssb_disable_hazmat"
                                        value="1"
                                        <?php checked(get_option('ssb_disable_hazmat', '0'), '1'); ?>>
                                    Disable Hazmat
                                </label>

                                <p class="description">
                                    These options are globally disabled and cannot be selected during label creation.
                                </p>
                            </td>
                        </tr>

                    </tbody>
                </table>

<hr style="margin:24px 0;">

<h2>Admin Rate Adjustment Settings</h2>
<p>These values control the optional add-on amounts shown on admin carrier cards and will be used for internal adjusted-rate calculations.</p>

<table class="form-table" role="presentation">
    <tbody>
        <tr>
            <th scope="row" colspan="2"><h3 style="margin:0;">USPS</h3></th>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_usps_signature_required">Signature Required</label></th>
            <td>
                <input name="ssb_usps_signature_required" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_usps_signature_required" class="regular-text" value="<?php echo esc_attr($adjustments['usps_signature_required']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_usps_adult_signature_required">Adult Signature Required</label></th>
            <td>
                <input name="ssb_usps_adult_signature_required" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_usps_adult_signature_required" class="regular-text" value="<?php echo esc_attr($adjustments['usps_adult_signature_required']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_usps_insurance">Insurance</label></th>
            <td>
                <input name="ssb_usps_insurance" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_usps_insurance" class="regular-text" value="<?php echo esc_attr($adjustments['usps_insurance']); ?>">
                <p class="description">Charged per additional $100 of declared value above the service’s included insurance. Rounded up to the next $100.</p>
            </td>
        </tr>

        <tr>
            <th scope="row" colspan="2"><h3 style="margin:16px 0 0;">UPS</h3></th>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_signature_required">Signature Required</label></th>
            <td>
                <input name="ssb_ups_signature_required" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_signature_required" class="regular-text" value="<?php echo esc_attr($adjustments['ups_signature_required']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_adult_signature_required">Adult Signature Required</label></th>
            <td>
                <input name="ssb_ups_adult_signature_required" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_adult_signature_required" class="regular-text" value="<?php echo esc_attr($adjustments['ups_adult_signature_required']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_carbon_neutral">Carbon Neutral</label></th>
            <td>
                <input name="ssb_ups_carbon_neutral" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_carbon_neutral" class="regular-text" value="<?php echo esc_attr($adjustments['ups_carbon_neutral']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_saturday_delivery">Saturday Delivery</label></th>
            <td>
                <input name="ssb_ups_saturday_delivery" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_saturday_delivery" class="regular-text" value="<?php echo esc_attr($adjustments['ups_saturday_delivery']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_additional_handling">Additional Handling</label></th>
            <td>
                <input name="ssb_ups_additional_handling" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_additional_handling" class="regular-text" value="<?php echo esc_attr($adjustments['ups_additional_handling']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_insurance">Insurance</label></th>
            <td>
                <input name="ssb_ups_insurance" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_insurance" class="regular-text" value="<?php echo esc_attr($adjustments['ups_insurance']); ?>">
                <p class="description">Charged per additional $100 of declared value above the service’s included insurance. Rounded up to the next $100.</p>
            </td>
        </tr>
    </tbody>
</table>

<?php submit_button('Save Settings'); ?>
            </form>
        </div>
        <?php
    }

        protected static function get_rate_adjustment_settings() {
            return array(
                'usps_signature_required'       => self::normalize_money_setting(get_option('ssb_usps_signature_required', '3.95')),
                'usps_adult_signature_required' => self::normalize_money_setting(get_option('ssb_usps_adult_signature_required', '9.70')),
                'usps_insurance'                => self::normalize_money_setting(get_option('ssb_usps_insurance', '0.00')),
                'ups_signature_required'        => self::normalize_money_setting(get_option('ssb_ups_signature_required', '6.25')),
                'ups_adult_signature_required'  => self::normalize_money_setting(get_option('ssb_ups_adult_signature_required', '7.50')),
                'ups_carbon_neutral'            => self::normalize_money_setting(get_option('ssb_ups_carbon_neutral', '0.05')),
                'ups_saturday_delivery'         => self::normalize_money_setting(get_option('ssb_ups_saturday_delivery', '16.00')),
                'ups_additional_handling'       => self::normalize_money_setting(get_option('ssb_ups_additional_handling', '14.25')),
                'ups_insurance'                 => self::normalize_money_setting(get_option('ssb_ups_insurance', '0.00')),
            );
        }

    /**
     * Return shipper settings, falling back to Woo/store values.
     *
     * @return array
     */
    protected static function get_shipper_settings() {
        $saved = get_option('ssb_shipper_origin', array());
        $saved = is_array($saved) ? $saved : array();

        $country_state = (string) get_option('woocommerce_default_country', '');
        $country = '';
        $state   = '';

        if ($country_state !== '') {
            $parts   = explode(':', $country_state);
            $country = isset($parts[0]) ? strtoupper(trim((string) $parts[0])) : '';
            $state   = isset($parts[1]) ? strtoupper(trim((string) $parts[1])) : '';
        }

        $store_company = (string) get_option('woocommerce_store_company', '');
        if ($store_company === '') {
            $store_company = (string) get_option('woocommerce_store_name', '');
        }
        if ($store_company === '') {
            $store_company = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        }

        $defaults = array(
            'name'    => 'Shipping Department',
            'company' => $store_company,
            'street1' => (string) get_option('woocommerce_store_address', ''),
            'street2' => (string) get_option('woocommerce_store_address_2', ''),
            'city'    => (string) get_option('woocommerce_store_city', ''),
            'state'   => $state,
            'zip'     => (string) get_option('woocommerce_store_postcode', ''),
            'country' => $country,
            'phone'   => (string) get_option('woocommerce_store_phone', ''),
            'email'   => (string) get_option('admin_email', ''),
        );

        if ($defaults['email'] === '') {
            $defaults['email'] = (string) get_option('woocommerce_email_from_address', '');
        }

        return wp_parse_args($saved, $defaults);
    }

        public static function sanitize_money_setting($value) {
            return self::normalize_money_setting($value);
        }

    /**
     * Sanitize shipper origin settings.
     *
     * @param mixed $input
     * @return array
     */
    public static function sanitize_shipper_origin_settings($input) {
        $input = is_array($input) ? $input : array();

        $country = isset($input['country']) ? strtoupper(trim((string) $input['country'])) : '';

        return array(
            'name'    => isset($input['name']) ? sanitize_text_field($input['name']) : '',
            'company' => isset($input['company']) ? sanitize_text_field($input['company']) : '',
            'street1' => isset($input['street1']) ? sanitize_text_field($input['street1']) : '',
            'street2' => isset($input['street2']) ? sanitize_text_field($input['street2']) : '',
            'city'    => isset($input['city']) ? sanitize_text_field($input['city']) : '',
            'state'   => isset($input['state']) ? sanitize_text_field($input['state']) : '',
            'zip'     => isset($input['zip']) ? sanitize_text_field($input['zip']) : '',
            'country' => preg_replace('/[^A-Z]/', '', $country),
            'phone'   => isset($input['phone']) ? sanitize_text_field($input['phone']) : '',
            'email'   => isset($input['email']) ? sanitize_email($input['email']) : '',
        );
    }

        public static function is_multipackage_mode_enabled() {
        return get_option('ssb_enable_multipackage_mode', 'no') === 'yes';
    }

    /**
     * Lightweight diagnostic payload for admin/debugging.
     *
     * @return array
     */
    public static function get_debug_context() {
        return array(
            'mode'        => self::is_test_mode() ? 'test' : 'live',
            'has_token'   => self::get_shippo_token() !== '',
            'origin'      => self::get_origin_address(),
        );
    }

    /**
     * Attempt to detect current Shippo mode from installed Shippo plugin options.
     *
     * This is intentionally defensive because third-party plugin option keys can vary.
     *
     * @return bool|null
     */
    protected static function detect_shippo_mode_from_existing_plugin() {
        $candidates = self::get_existing_shippo_option_candidates();

        foreach ($candidates as $option_name => $value) {
            if (!is_array($value)) {
                continue;
            }

            $flat = self::flatten_array_keys($value);

            $truthy_keys = array(
                'sandbox',
                'test_mode',
                'sandbox_mode',
                'is_test_mode',
                'enable_test_mode',
                'shippo_test_mode',
                'shippo_mode',
                'shippo_environment',
            );

            foreach ($truthy_keys as $key) {
                if (!array_key_exists($key, $flat)) {
                    continue;
                }

                $raw = $flat[$key];

                if (is_bool($raw)) {
                    return $raw;
                }

                $raw = strtolower(trim((string) $raw));

                if (in_array($raw, array('test', 'sandbox', 'yes', '1', 'true'), true)) {
                    return true;
                }

                if (in_array($raw, array('live', 'production', 'no', '0', 'false'), true)) {
                    return false;
                }
            }
        }

        return null;
    }

    /**
     * Attempt to detect live/test API tokens from installed Shippo plugin options.
     *
     * @return array{live:string,test:string}
     */
    protected static function detect_shippo_tokens_from_existing_plugin() {
        $result = array(
            'live' => '',
            'test' => '',
        );

        $candidates = self::get_existing_shippo_option_candidates();

        foreach ($candidates as $option_name => $value) {
            if (!is_array($value)) {
                continue;
            }

            $flat = self::flatten_array_keys($value);

            foreach ($flat as $key => $raw) {
                if (!is_scalar($raw)) {
                    continue;
                }

                $key_lc = strtolower((string) $key);
                $val    = trim((string) $raw);

                if ($val === '') {
                    continue;
                }

                if (
                    $result['test'] === '' &&
                    (
                        strpos($key_lc, 'testapitoken') !== false ||
                        strpos($key_lc, 'test_api_key') !== false ||
                        strpos($key_lc, 'test_token') !== false ||
                        strpos($key_lc, 'sandbox_api_key') !== false ||
                        strpos($key_lc, 'sandbox_token') !== false
                    )
                ) {
                    $result['test'] = $val;
                    continue;
                }

                if (
                    $result['live'] === '' &&
                    (
                        strpos($key_lc, 'liveapitoken') !== false ||
                        strpos($key_lc, 'live_api_key') !== false ||
                        strpos($key_lc, 'live_token') !== false ||
                        (
                            strpos($key_lc, 'shippo') !== false &&
                            (
                                strpos($key_lc, 'api_key') !== false ||
                                strpos($key_lc, 'api_token') !== false ||
                                strpos($key_lc, 'token') !== false
                            )
                        )
                    )
                ) {
                    $result['live'] = $val;
                    continue;
                }
            }
        }

        return $result;
    }

    /**
     * Gather likely Shippo plugin option records from wp_options.
     *
     * @return array
     */
    protected static function get_existing_shippo_option_candidates() {
        global $wpdb;

        $results = array();

        $like_patterns = array(
            'shippo',
            'wc_shippo',
            'one_team_shippo',
            'oneteamsoft',
        );

        foreach ($like_patterns as $pattern) {
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT option_name, option_value
                    FROM {$wpdb->options}
                    WHERE option_name LIKE %s
                    ",
                    '%' . $wpdb->esc_like($pattern) . '%'
                ),
                ARRAY_A
            );

            if (empty($rows)) {
                continue;
            }

            foreach ($rows as $row) {
                $name  = isset($row['option_name']) ? (string) $row['option_name'] : '';
                $value = isset($row['option_value']) ? maybe_unserialize($row['option_value']) : null;

                if ($name === '' || isset($results[$name])) {
                    continue;
                }

                $results[$name] = $value;
            }
        }

        return $results;
    }

    /**
     * Flatten nested option arrays into key => scalar value map.
     *
     * @param array  $array
     * @param string $prefix
     * @return array
     */
    protected static function flatten_array_keys(array $array, $prefix = '') {
        $flat = array();

        foreach ($array as $key => $value) {
            $key = (string) $key;
            $composed = $prefix === '' ? $key : $prefix . '.' . $key;

            if (is_array($value)) {
                $flat = array_merge($flat, self::flatten_array_keys($value, $composed));
                continue;
            }

            $flat[$key] = $value;
            $flat[$composed] = $value;
        }

        return $flat;
    }
}