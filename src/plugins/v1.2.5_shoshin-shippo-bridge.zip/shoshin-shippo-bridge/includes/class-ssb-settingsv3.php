<?php
if (!defined('ABSPATH')) {
    exit;
}

class SSB_Settings {

    const OPTION_WAREHOUSES            = 'ssb_warehouses';
    const OPTION_VENDORS               = 'ssb_vendors';
    const OPTION_MAIN_WAREHOUSE_LOGO_1 = 'ssb_main_warehouse_logo_1';
    const OPTION_MAIN_WAREHOUSE_LOGO_2 = 'ssb_main_warehouse_logo_2';
    const OPTION_FULFILLMENT_LANES     = 'ssb_fulfillment_lanes';

        /**
         * Initialize settings hooks.
         */
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'register_records_pages'), 20);
        add_action('admin_init', array(__CLASS__, 'register_settings'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'enqueue_records_admin_assets'));
        add_action('admin_post_ssb_save_warehouse', array(__CLASS__, 'handle_save_warehouse'));
        add_action('admin_post_ssb_save_vendor', array(__CLASS__, 'handle_save_vendor'));
        add_action('admin_post_ssb_toggle_warehouse_active', array(__CLASS__, 'handle_toggle_warehouse_active'));
        add_action('admin_post_ssb_toggle_vendor_active', array(__CLASS__, 'handle_toggle_vendor_active'));
        add_action('admin_post_ssb_delete_warehouse', array(__CLASS__, 'handle_delete_warehouse'));
        add_action('admin_post_ssb_delete_vendor', array(__CLASS__, 'handle_delete_vendor'));
        add_action('admin_post_ssb_assign_fulfillment_lane_class', array(__CLASS__, 'handle_assign_fulfillment_lane_class'));
        add_action('admin_post_ssb_remove_fulfillment_lane_class', array(__CLASS__, 'handle_remove_fulfillment_lane_class'));
        add_action('admin_post_ssb_save_fulfillment_lane_settings', array(__CLASS__, 'handle_save_fulfillment_lane_settings'));
        add_filter('plugin_action_links_' . SSB_BASENAME, array(__CLASS__, 'add_plugin_action_links'));
    }

        /**
         * Returns whether the bridge should use Shippo test mode.
         *
         * Resolution order:
         * 1. Manual override option (future-proofed)
         * 2. Detected Shippo plugin settings
         * 3. Default false (live)
         *
         * @return bool
         */
        public static function is_test_mode() {
            $manual = get_option('ssb_shippo_mode', '');
            if ($manual === 'test') {
                return true;
            }
            if ($manual === 'live') {
                return false;
            }

            $detected = self::detect_shippo_mode_from_existing_plugin();
            if ($detected !== null) {
                return (bool) $detected;
            }

            return false;
        }

        /**
         * Return the active Shippo API token.
         *
         * Resolution order:
         * 1. Manual override options (future-proofed)
         * 2. Existing Shippo plugin settings
         *
         * @return string
         */
        public static function get_shippo_token() {
            $is_test = self::is_test_mode();

            $manual_live = trim((string) get_option('ssb_shippo_live_token', ''));
            $manual_test = trim((string) get_option('ssb_shippo_test_token', ''));

            if ($is_test && $manual_test !== '') {
                return $manual_test;
            }

            if (!$is_test && $manual_live !== '') {
                return $manual_live;
            }

            $detected = self::detect_shippo_tokens_from_existing_plugin();

            if ($is_test && !empty($detected['test'])) {
                return (string) $detected['test'];
            }

            if (!$is_test && !empty($detected['live'])) {
                return (string) $detected['live'];
            }

            return '';
        }

        /**
         * Return the store origin from Woo settings.
         *
         * @return array
         */
        public static function get_origin_address() {
            $settings = self::get_shipper_settings();
            /*$adjustments = self::get_rate_adjustment_settings();*/
            $country = strtoupper(trim((string) $settings['country']));
            $phone   = self::normalize_phone($settings['phone'], $country);

            return array(
                'name'     => (string) $settings['name'],
                'company'  => (string) $settings['company'],
                'street1'  => (string) $settings['street1'],
                'street2'  => (string) $settings['street2'],
                'city'     => (string) $settings['city'],
                'state'    => (string) $settings['state'],
                'zip'      => (string) $settings['zip'],
                'country'  => $country,
                'phone'    => $phone,
                'email'    => (string) $settings['email'],
            );
        }

            /**
         * Normalize phone values for carrier-facing payloads.
         *
         * @param string $phone
         * @param string $country
         * @return string
         */
        protected static function normalize_phone($phone, $country = '') {
            $phone   = trim((string) $phone);
            $country = strtoupper(trim((string) $country));

            if ($phone === '') {
                return '';
            }

            $digits = preg_replace('/\D+/', '', $phone);

            if ($country === 'US' && strlen($digits) === 11 && strpos($digits, '1') === 0) {
                $digits = substr($digits, 1);
            }

            return $digits;
        }

        protected static function normalize_money_setting($value) {
        $value = is_scalar($value) ? (string) $value : '';
        $value = trim($value);

        if ($value === '') {
            return '0.00';
        }

        $value = str_replace(',', '', $value);

        if (!is_numeric($value)) {
            return '0.00';
        }

        $value = (float) $value;

        if ($value < 0) {
            $value = 0;
        }

        return number_format($value, 2, '.', '');
    }

            /**
         * Register plugin settings page under Settings.
         *
         * @return void
         */
        public static function register_settings_page() {
            add_submenu_page(
                'ssb-warehouses',
                'Settings',
                'Settings',
                'manage_woocommerce',
                'admin.php?page=ssb-settings',
                array(__CLASS__, 'render_settings_page')
            );
        }

            public static function register_records_pages() {
        add_menu_page(
            'Shippo',
            'Shippo',
            'manage_woocommerce',
            'ssb-warehouses',
            array(__CLASS__, 'render_warehouses_page'),
            'dashicons-location-alt',
            56
        );

        add_submenu_page(
            'ssb-warehouses',
            'Warehouses',
            'Warehouses',
            'manage_woocommerce',
            'ssb-warehouses',
            array(__CLASS__, 'render_warehouses_page')
        );

        add_submenu_page(
            'ssb-warehouses',
            'Vendors',
            'Vendors',
            'manage_woocommerce',
            'ssb-vendors',
            array(__CLASS__, 'render_vendors_page')
        );

        add_submenu_page(
            'ssb-warehouses',
            'Fulfillment Lanes',
            'Fulfillment Lanes',
            'manage_woocommerce',
            'ssb-fulfillment-lanes',
            array(__CLASS__, 'render_fulfillment_lanes_page')
        );

        add_submenu_page(
            'ssb-warehouses',
            'Settings',
            'Settings',
            'manage_woocommerce',
            'ssb-settings',
            array(__CLASS__, 'render_settings_page')
        );
    }

    protected static function get_warehouses() {
        $rows = get_option(self::OPTION_WAREHOUSES, array());
        return is_array($rows) ? array_values($rows) : array();
    }

    protected static function get_vendors() {
        $rows = get_option(self::OPTION_VENDORS, array());
        return is_array($rows) ? array_values($rows) : array();
    }

    protected static function get_next_sequential_code($prefix, array $rows) {
        $max = 0;

        foreach ($rows as $row) {
            $code = isset($row['code']) ? (string) $row['code'] : '';
            if (preg_match('/^' . preg_quote($prefix, '/') . '(\d+)$/', $code, $matches)) {
                $num = (int) $matches[1];
                if ($num > $max) {
                    $max = $num;
                }
            }
        }

        if ($max < 1) {
            return $prefix . '1';
        }

        return $prefix . ($max + 1);
    }

    protected static function sanitize_record_flag($value) {
        return !empty($value) && (string) $value === '1' ? '1' : '0';
    }

        protected static function find_record_by_code(array $rows, $code) {
        foreach ($rows as $index => $row) {
            if (!empty($row['code']) && (string) $row['code'] === (string) $code) {
                return array(
                    'index'  => $index,
                    'record' => $row,
                );
            }
        }

        return null;
    }

    protected static function get_admin_page_url($slug, array $args = array()) {
        $args = array_merge(array('page' => $slug), $args);
        return add_query_arg($args, admin_url('admin.php'));
    }

    protected static function render_row_action_link($action, $label, $args = array(), $class = '') {
        $url = wp_nonce_url(
            add_query_arg($args, admin_url('admin-post.php?action=' . $action)),
            $action
        );

        return '<a class="' . esc_attr($class) . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }

    protected static function sanitize_warehouse_record($input, $code) {
        $input = is_array($input) ? $input : array();

        return array(
            'code'         => sanitize_text_field($code),
            'active'       => self::sanitize_record_flag($input['active'] ?? '0'),
            'name'         => sanitize_text_field($input['name'] ?? ''),
            'address1'     => sanitize_text_field($input['address1'] ?? ''),
            'address2'     => sanitize_text_field($input['address2'] ?? ''),
            'city'         => sanitize_text_field($input['city'] ?? ''),
            'state'        => sanitize_text_field($input['state'] ?? ''),
            'postal_code'  => sanitize_text_field($input['postal_code'] ?? ''),
            'country'      => strtoupper(preg_replace('/[^A-Z]/', '', (string) ($input['country'] ?? ''))),
            'phone'        => sanitize_text_field($input['phone'] ?? ''),
            'email'        => sanitize_email($input['email'] ?? ''),
        );
    }

    protected static function sanitize_vendor_record($input, $code) {
        $input = is_array($input) ? $input : array();

        return array(
            'code'         => sanitize_text_field($code),
            'active'       => self::sanitize_record_flag($input['active'] ?? '0'),
            'company_name' => sanitize_text_field($input['company_name'] ?? ''),
            'contact'      => sanitize_text_field($input['contact'] ?? ''),
            'address1'     => sanitize_text_field($input['address1'] ?? ''),
            'address2'     => sanitize_text_field($input['address2'] ?? ''),
            'city'         => sanitize_text_field($input['city'] ?? ''),
            'state'        => sanitize_text_field($input['state'] ?? ''),
            'postal_code'  => sanitize_text_field($input['postal_code'] ?? ''),
            'country'      => strtoupper(preg_replace('/[^A-Z]/', '', (string) ($input['country'] ?? ''))),
            'phone'        => sanitize_text_field($input['phone'] ?? ''),
            'email'        => sanitize_email($input['email'] ?? ''),
            'image_id'     => absint($input['image_id'] ?? 0),
        );
    }

    public static function handle_save_warehouse() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_save_warehouse');

        $rows = self::get_warehouses();
        $edit_code = isset($_POST['edit_code']) ? sanitize_text_field($_POST['edit_code']) : '';

        if ($edit_code !== '') {
            $found = self::find_record_by_code($rows, $edit_code);

            if (!$found) {
                wp_safe_redirect(admin_url('admin.php?page=ssb-warehouses'));
                exit;
            }

            $existing = $found['record'];
            $record = self::sanitize_warehouse_record($_POST['warehouse'] ?? array(), $existing['code']);
            $record['active'] = isset($existing['active']) ? $existing['active'] : '0';
            $rows[$found['index']] = $record;
        } else {
            $code = self::get_next_sequential_code('warehouse_', $rows);
            $record = self::sanitize_warehouse_record($_POST['warehouse'] ?? array(), $code);
            $record['active'] = '0';
            $rows[] = $record;
        }

        update_option(self::OPTION_WAREHOUSES, array_values($rows), false);

        wp_safe_redirect(admin_url('admin.php?page=ssb-warehouses'));
        exit;
    }

    public static function handle_save_vendor() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_save_vendor');

        $rows = self::get_vendors();
        $edit_code = isset($_POST['edit_code']) ? sanitize_text_field($_POST['edit_code']) : '';

        if ($edit_code !== '') {
            $found = self::find_record_by_code($rows, $edit_code);

            if (!$found) {
                wp_safe_redirect(admin_url('admin.php?page=ssb-vendors'));
                exit;
            }

            $existing = $found['record'];
            $record = self::sanitize_vendor_record($_POST['vendor'] ?? array(), $existing['code']);
            $record['active'] = isset($existing['active']) ? $existing['active'] : '0';
            $rows[$found['index']] = $record;
        } else {
            $code = self::get_next_sequential_code('vendor_', $rows);
            $record = self::sanitize_vendor_record($_POST['vendor'] ?? array(), $code);
            $record['active'] = '0';
            $rows[] = $record;
        }

        update_option(self::OPTION_VENDORS, array_values($rows), false);

        wp_safe_redirect(admin_url('admin.php?page=ssb-vendors'));
        exit;
    }

        public static function handle_toggle_warehouse_active() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_toggle_warehouse_active');

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $rows = self::get_warehouses();
        $found = self::find_record_by_code($rows, $code);

        if ($found) {
            $rows[$found['index']]['active'] = (!empty($rows[$found['index']]['active']) && $rows[$found['index']]['active'] === '1') ? '0' : '1';
            update_option(self::OPTION_WAREHOUSES, array_values($rows), false);
        }

        wp_safe_redirect(admin_url('admin.php?page=ssb-warehouses'));
        exit;
    }

    public static function handle_toggle_vendor_active() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_toggle_vendor_active');

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $rows = self::get_vendors();
        $found = self::find_record_by_code($rows, $code);

        if ($found) {
            $rows[$found['index']]['active'] = (!empty($rows[$found['index']]['active']) && $rows[$found['index']]['active'] === '1') ? '0' : '1';
            update_option(self::OPTION_VENDORS, array_values($rows), false);
        }

        wp_safe_redirect(admin_url('admin.php?page=ssb-vendors'));
        exit;
    }

    public static function handle_delete_warehouse() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_delete_warehouse');

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $rows = self::get_warehouses();

        $rows = array_values(array_filter($rows, function($row) use ($code) {
            return empty($row['code']) || (string) $row['code'] !== (string) $code;
        }));

        update_option(self::OPTION_WAREHOUSES, $rows, false);

        wp_safe_redirect(admin_url('admin.php?page=ssb-warehouses'));
        exit;
    }

    public static function handle_delete_vendor() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_delete_vendor');

        $code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
        $rows = self::get_vendors();

        $rows = array_values(array_filter($rows, function($row) use ($code) {
            return empty($row['code']) || (string) $row['code'] !== (string) $code;
        }));

        update_option(self::OPTION_VENDORS, $rows, false);

        wp_safe_redirect(admin_url('admin.php?page=ssb-vendors'));
        exit;
    }

        public static function enqueue_records_admin_assets($hook_suffix) {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';

        if (!in_array($page, array('ssb-settings', 'ssb-vendors', 'ssb-fulfillment-lanes'), true)) {
            return;
        }

        wp_enqueue_media();

        wp_add_inline_script(
            'jquery-core',
            "
            jQuery(function($){
                function bindMediaPicker(buttonSelector, inputSelector, previewSelector) {
                    $(document).on('click', buttonSelector, function(e){
                        e.preventDefault();

                        var frame = wp.media({
                            title: 'Select Image',
                            button: { text: 'Use this image' },
                            multiple: false,
                            library: { type: 'image' }
                        });

                        frame.on('select', function(){
                            var attachment = frame.state().get('selection').first().toJSON();
                            $(inputSelector).val(attachment.id);
                            $(previewSelector).html('<img src=\"' + attachment.url + '\" style=\"max-width:100%; height:auto; border:1px solid #dcdcde;\" />');
                        });

                        frame.open();
                    });
                }

                bindMediaPicker('#ssb-main-warehouse-logo-1-select', '#ssb_main_warehouse_logo_1', '#ssb-main-warehouse-logo-1-preview');
                bindMediaPicker('#ssb-main-warehouse-logo-2-select', '#ssb_main_warehouse_logo_2', '#ssb-main-warehouse-logo-2-preview');
                bindMediaPicker('#ssb-vendor-image-select', '#vendor_image_id', '#ssb-vendor-image-preview');
            });
            "
        );
    }

        protected static function get_fulfillment_lanes() {
        $stored = get_option(self::OPTION_FULFILLMENT_LANES, array());
        $stored = is_array($stored) ? $stored : array();

        $normalize_lane = function($lane_key) use ($stored) {
            $raw = isset($stored[$lane_key]) ? $stored[$lane_key] : array();

            // Backward compatibility: old format stored just an array of term IDs.
            if (is_array($raw) && array_keys($raw) === range(0, count($raw) - 1)) {
                return array(
                    'shipping_classes' => array_values(array_unique(array_map('absint', $raw))),
                    'customer_shipping_message' => '',
                );
            }

            $raw = is_array($raw) ? $raw : array();

            return array(
                'shipping_classes' => isset($raw['shipping_classes']) && is_array($raw['shipping_classes'])
                    ? array_values(array_unique(array_map('absint', $raw['shipping_classes'])))
                    : array(),
                'customer_shipping_message' => isset($raw['customer_shipping_message'])
                    ? sanitize_textarea_field($raw['customer_shipping_message'])
                    : '',
            );
        };

        return array(
            'batch'     => $normalize_lane('batch'),
            'immediate' => $normalize_lane('immediate'),
            'external'  => $normalize_lane('external'),
        );
    }

    protected static function save_fulfillment_lanes($lanes) {
        update_option(self::OPTION_FULFILLMENT_LANES, $lanes, false);
    }

    protected static function get_all_shipping_classes_for_mapping() {
        $terms = get_terms(array(
            'taxonomy'   => 'product_shipping_class',
            'hide_empty' => false,
        ));

        if (is_wp_error($terms) || !is_array($terms)) {
            return array();
        }

        return $terms;
    }

    protected static function get_lane_label($lane_key) {
        $labels = array(
            'batch'     => 'Batch Production',
            'immediate' => 'Immediate',
            'external'  => 'External',
        );

        return isset($labels[$lane_key]) ? $labels[$lane_key] : $lane_key;
    }

    protected static function get_lane_note($lane_key) {
        $notes = array(
            'batch'     => 'Intended for production runs with MOQ requirements. Shippo is intentionally blocked from servicing this lane at checkout. Shipping may be collected later and fulfilled after production is complete.',
            'immediate' => 'Intended for normal in-stock warehousing operations. Shippo is active for this lane at checkout and during fulfillment.',
            'external'  => 'Intended for external drop-shipping vendors who handle fulfillment directly. Standard in-house shipping and Shippo behavior are bypassed for this lane.',
        );

        return isset($notes[$lane_key]) ? $notes[$lane_key] : '';
    }

    protected static function find_lane_for_shipping_class($term_id, array $lanes) {
        foreach ($lanes as $lane_key => $lane_config) {
            $term_ids = isset($lane_config['shipping_classes']) && is_array($lane_config['shipping_classes'])
                ? $lane_config['shipping_classes']
                : array();

            if (in_array((int) $term_id, array_map('intval', $term_ids), true)) {
                return $lane_key;
            }
        }

        return '';
    }

    public static function handle_assign_fulfillment_lane_class() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_assign_fulfillment_lane_class');

        $lane = isset($_POST['lane']) ? sanitize_text_field($_POST['lane']) : '';
        $term_ids = isset($_POST['shipping_class_ids']) && is_array($_POST['shipping_class_ids'])
            ? array_values(array_unique(array_map('absint', $_POST['shipping_class_ids'])))
            : array();

        $valid_lanes = array('batch', 'immediate', 'external');
        if (!in_array($lane, $valid_lanes, true)) {
            wp_safe_redirect(admin_url('admin.php?page=ssb-fulfillment-lanes'));
            exit;
        }

        if (empty($term_ids)) {
            wp_safe_redirect(add_query_arg('ssb_lane_notice', 'none_selected', admin_url('admin.php?page=ssb-fulfillment-lanes')));
            exit;
        }

        $lanes = self::get_fulfillment_lanes();

        foreach ($term_ids as $term_id) {
            $existing_lane = self::find_lane_for_shipping_class($term_id, $lanes);

            if ($existing_lane !== '' && $existing_lane !== $lane) {
                wp_safe_redirect(add_query_arg(
                    array(
                        'page'             => 'ssb-fulfillment-lanes',
                        'ssb_lane_notice'  => 'already_assigned',
                    ),
                    admin_url('admin.php')
                ));
                exit;
            }
        }

        $existing_ids = isset($lanes[$lane]['shipping_classes']) && is_array($lanes[$lane]['shipping_classes'])
            ? $lanes[$lane]['shipping_classes']
            : array();

        $lanes[$lane]['shipping_classes'] = array_values(array_unique(array_merge($existing_ids, $term_ids)));
        self::save_fulfillment_lanes($lanes);

        wp_safe_redirect(admin_url('admin.php?page=ssb-fulfillment-lanes'));
        exit;
    }

    public static function handle_remove_fulfillment_lane_class() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_remove_fulfillment_lane_class');

        $lane = isset($_GET['lane']) ? sanitize_text_field($_GET['lane']) : '';
        $term_id = isset($_GET['term_id']) ? absint($_GET['term_id']) : 0;

        $valid_lanes = array('batch', 'immediate', 'external');
        if (!in_array($lane, $valid_lanes, true) || $term_id < 1) {
            wp_safe_redirect(admin_url('admin.php?page=ssb-fulfillment-lanes'));
            exit;
        }

        $lanes = self::get_fulfillment_lanes();
        $existing_ids = isset($lanes[$lane]['shipping_classes']) && is_array($lanes[$lane]['shipping_classes'])
            ? $lanes[$lane]['shipping_classes']
            : array();

        $lanes[$lane]['shipping_classes'] = array_values(array_filter($existing_ids, function($id) use ($term_id) {
            return (int) $id !== (int) $term_id;
        }));

        self::save_fulfillment_lanes($lanes);

        wp_safe_redirect(admin_url('admin.php?page=ssb-fulfillment-lanes'));
        exit;
    }

    public static function render_fulfillment_lanes_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $lanes = self::get_fulfillment_lanes();
        $all_terms = self::get_all_shipping_classes_for_mapping();

        $notice = isset($_GET['ssb_lane_notice']) ? sanitize_text_field($_GET['ssb_lane_notice']) : '';
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Fulfillment Lanes</h1>
            <hr class="wp-header-end">

            <div class="notice notice-info inline">
                <p>Remember to assign the appropriate WooCommerce Shipping Class to each product on its individual product page.</p>
            </div>

            <?php if ($notice === 'already_assigned') : ?>
                <div class="notice notice-error inline">
                    <p>A selected shipping class is already assigned to another fulfillment lane. Unassign it first before reassigning.</p>
                </div>
            <?php elseif ($notice === 'none_selected') : ?>
                <div class="notice notice-warning inline">
                    <p>Select one or more shipping classes before clicking Assign.</p>
                </div>
            <?php elseif ($notice === 'lane_saved') : ?>
                <div class="notice notice-success inline">
                    <p>Fulfillment lane settings saved.</p>
                </div>
            <?php endif; ?>

            <?php foreach (array('batch', 'immediate', 'external') as $lane_key) : ?>
                <?php
                $assigned_ids = isset($lanes[$lane_key]['shipping_classes']) && is_array($lanes[$lane_key]['shipping_classes'])
                    ? $lanes[$lane_key]['shipping_classes']
                    : array();

                $customer_shipping_message = isset($lanes[$lane_key]['customer_shipping_message'])
                    ? $lanes[$lane_key]['customer_shipping_message']
                    : '';

                $available_terms = array_filter($all_terms, function($term) use ($lanes) {
                    $existing_lane = self::find_lane_for_shipping_class($term->term_id, $lanes);
                    return $existing_lane === '';
                });
                ?>
                <div style="background:#fff; border:1px solid #dcdcde; padding:20px; margin:0 0 20px;">
                    <h2 style="margin-top:0;"><?php echo esc_html(self::get_lane_label($lane_key)); ?></h2>
                    <p class="description" style="max-width:900px; margin-bottom:16px;">
                        <?php echo esc_html(self::get_lane_note($lane_key)); ?>
                    </p>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:18px;">
                        <input type="hidden" name="action" value="ssb_assign_fulfillment_lane_class">
                        <input type="hidden" name="lane" value="<?php echo esc_attr($lane_key); ?>">
                        <?php wp_nonce_field('ssb_assign_fulfillment_lane_class'); ?>

                        <div style="display:flex; gap:12px; align-items:flex-start; flex-wrap:wrap;">
                            <select name="shipping_class_ids[]" multiple size="6" style="min-width:320px; max-width:420px;">
                                <?php foreach ($available_terms as $term) : ?>
                                    <option value="<?php echo esc_attr($term->term_id); ?>">
                                        <?php echo esc_html($term->name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <div>
                                <?php submit_button('Assign', 'secondary', 'submit', false); ?>
                                <p class="description" style="margin-top:8px;">Select one or more shipping classes and click Assign.</p>
                            </div>
                        </div>
                    </form>

                    <table class="widefat striped" style="max-width:900px; margin-bottom:18px;">
                        <thead>
                            <tr>
                                <th>Assigned Shipping Class</th>
                                <th style="width:120px;">Slug</th>
                                <th style="width:120px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($assigned_ids)) : ?>
                                <tr>
                                    <td colspan="3">No shipping classes assigned.</td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($assigned_ids as $term_id) : ?>
                                    <?php $term = get_term($term_id, 'product_shipping_class'); ?>
                                    <?php if (!$term || is_wp_error($term)) { continue; } ?>
                                    <tr>
                                        <td><?php echo esc_html($term->name); ?></td>
                                        <td><?php echo esc_html($term->slug); ?></td>
                                        <td>
                                            <?php
                                            echo self::render_row_action_link(
                                                'ssb_remove_fulfillment_lane_class',
                                                'Unassign',
                                                array(
                                                    'lane'    => $lane_key,
                                                    'term_id' => $term->term_id,
                                                ),
                                                'submitdelete'
                                            );
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="max-width:900px;">
                        <input type="hidden" name="action" value="ssb_save_fulfillment_lane_settings">
                        <input type="hidden" name="lane" value="<?php echo esc_attr($lane_key); ?>">
                        <?php wp_nonce_field('ssb_save_fulfillment_lane_settings'); ?>

                        <table class="form-table" role="presentation" style="margin-top:0;">
                            <tbody>
                                <tr>
                                    <th scope="row" style="width:220px;">
                                        <label for="customer_shipping_message_<?php echo esc_attr($lane_key); ?>">Customer Shipping Message</label>
                                    </th>
                                    <td>
                                        <textarea
                                            id="customer_shipping_message_<?php echo esc_attr($lane_key); ?>"
                                            name="customer_shipping_message"
                                            rows="3"
                                            class="large-text"
                                        ><?php echo esc_textarea($customer_shipping_message); ?></textarea>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <?php submit_button('Save Lane Settings', 'secondary', 'submit', false); ?>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }

        public static function handle_save_fulfillment_lane_settings() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized.');
        }

        check_admin_referer('ssb_save_fulfillment_lane_settings');

        $lane = isset($_POST['lane']) ? sanitize_text_field($_POST['lane']) : '';
        $valid_lanes = array('batch', 'immediate', 'external');

        if (!in_array($lane, $valid_lanes, true)) {
            wp_safe_redirect(admin_url('admin.php?page=ssb-fulfillment-lanes'));
            exit;
        }

        $lanes = self::get_fulfillment_lanes();
        $lanes[$lane]['customer_shipping_message'] = isset($_POST['customer_shipping_message'])
            ? sanitize_textarea_field($_POST['customer_shipping_message'])
            : '';

        self::save_fulfillment_lanes($lanes);

        wp_safe_redirect(add_query_arg(
            array(
                'page'             => 'ssb-fulfillment-lanes',
                'ssb_lane_notice'  => 'lane_saved',
            ),
            admin_url('admin.php')
        ));
        exit;
    }

    public static function render_warehouses_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $rows = self::get_warehouses();
        $edit_code = isset($_GET['edit']) ? sanitize_text_field($_GET['edit']) : '';
        $editing = $edit_code !== '' ? self::find_record_by_code($rows, $edit_code) : null;
        $record = $editing ? $editing['record'] : array(
            'name'        => '',
            'address1'    => '',
            'address2'    => '',
            'city'        => '',
            'state'       => '',
            'postal_code' => '',
            'country'     => 'US',
            'phone'       => '',
            'email'       => '',
        );
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Warehouses</h1>
            <hr class="wp-header-end">

            <div class="notice notice-info inline">
                <p><strong>Main Warehouse</strong> is sourced from WooCommerce store settings.</p>
            </div>

            <div style="display:grid; grid-template-columns: 34% 1fr; gap: 24px; align-items:start;">
                <div>
                    <h2><?php echo $editing ? 'Edit Warehouse' : 'Add New Warehouse'; ?></h2>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="ssb_save_warehouse">
                        <?php wp_nonce_field('ssb_save_warehouse'); ?>

                        <?php if ($editing) : ?>
                            <input type="hidden" name="edit_code" value="<?php echo esc_attr($record['code']); ?>">
                        <?php endif; ?>

                        <table class="form-table" role="presentation">
                            <tbody>
                                <tr>
                                    <th scope="row"><label for="warehouse_name">Location Name</label></th>
                                    <td><input type="text" id="warehouse_name" name="warehouse[name]" class="regular-text" value="<?php echo esc_attr($record['name'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_address1">Address1</label></th>
                                    <td><input type="text" id="warehouse_address1" name="warehouse[address1]" class="regular-text" value="<?php echo esc_attr($record['address1'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_address2">Address2</label></th>
                                    <td><input type="text" id="warehouse_address2" name="warehouse[address2]" class="regular-text" value="<?php echo esc_attr($record['address2'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_city">City</label></th>
                                    <td><input type="text" id="warehouse_city" name="warehouse[city]" class="regular-text" value="<?php echo esc_attr($record['city'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_state">State</label></th>
                                    <td><input type="text" id="warehouse_state" name="warehouse[state]" class="regular-text" value="<?php echo esc_attr($record['state'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_postal_code">Postal Code</label></th>
                                    <td><input type="text" id="warehouse_postal_code" name="warehouse[postal_code]" class="regular-text" value="<?php echo esc_attr($record['postal_code'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_country">Country</label></th>
                                    <td><input type="text" id="warehouse_country" name="warehouse[country]" class="regular-text" maxlength="2" value="<?php echo esc_attr($record['country'] ?? 'US'); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_phone">Phone</label></th>
                                    <td><input type="text" id="warehouse_phone" name="warehouse[phone]" class="regular-text" value="<?php echo esc_attr($record['phone'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="warehouse_email">Email</label></th>
                                    <td><input type="email" id="warehouse_email" name="warehouse[email]" class="regular-text" value="<?php echo esc_attr($record['email'] ?? ''); ?>"></td>
                                </tr>
                            </tbody>
                        </table>

                        <?php submit_button($editing ? 'Save Warehouse' : 'Add New Warehouse'); ?>
                    </form>
                </div>

                <div>
                    <table class="widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Location Name</th>
                                <th>City</th>
                                <th>State</th>
                                <th style="width:90px;">Active</th>
                                <th style="width:140px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($rows)) : ?>
                                <tr>
                                    <td colspan="5">No warehouses found.</td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($rows as $row) : ?>
                                    <tr>
                                        <td><?php echo esc_html($row['name'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['city'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['state'] ?? ''); ?></td>
                                        <td>
                                            <?php
                                            echo self::render_row_action_link(
                                                'ssb_toggle_warehouse_active',
                                                (!empty($row['active']) && $row['active'] === '1') ? 'Active' : 'Inactive',
                                                array('code' => $row['code']),
                                                (!empty($row['active']) && $row['active'] === '1') ? 'button-link' : 'button-link-delete'
                                            );
                                            ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url(self::get_admin_page_url('ssb-warehouses', array('edit' => $row['code']))); ?>">Edit</a>
                                            |
                                            <?php
                                            echo self::render_row_action_link(
                                                'ssb_delete_warehouse',
                                                'Delete',
                                                array('code' => $row['code']),
                                                'submitdelete'
                                            );
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    public static function render_vendors_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $rows = self::get_vendors();
        $edit_code = isset($_GET['edit']) ? sanitize_text_field($_GET['edit']) : '';
        $editing = $edit_code !== '' ? self::find_record_by_code($rows, $edit_code) : null;
        $record = $editing ? $editing['record'] : array(
            'company_name' => '',
            'contact'      => '',
            'address1'     => '',
            'address2'     => '',
            'city'         => '',
            'state'        => '',
            'postal_code'  => '',
            'country'      => 'US',
            'phone'        => '',
            'email'        => '',
            'image_id'     => 0,
        );
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Vendors</h1>
            <hr class="wp-header-end">

            <div style="display:grid; grid-template-columns: 34% 1fr; gap: 24px; align-items:start;">
                <div>
                    <h2><?php echo $editing ? 'Edit Vendor' : 'Add New Vendor'; ?></h2>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="ssb_save_vendor">
                        <?php wp_nonce_field('ssb_save_vendor'); ?>

                        <?php if ($editing) : ?>
                            <input type="hidden" name="edit_code" value="<?php echo esc_attr($record['code']); ?>">
                        <?php endif; ?>

                        <table class="form-table" role="presentation">
                            <tbody>
                                <tr>
                                    <th scope="row"><label for="vendor_company_name">Company Name</label></th>
                                    <td><input type="text" id="vendor_company_name" name="vendor[company_name]" class="regular-text" value="<?php echo esc_attr($record['company_name'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_contact">Contact</label></th>
                                    <td><input type="text" id="vendor_contact" name="vendor[contact]" class="regular-text" value="<?php echo esc_attr($record['contact'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_address1">Address1</label></th>
                                    <td><input type="text" id="vendor_address1" name="vendor[address1]" class="regular-text" value="<?php echo esc_attr($record['address1'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_address2">Address2</label></th>
                                    <td><input type="text" id="vendor_address2" name="vendor[address2]" class="regular-text" value="<?php echo esc_attr($record['address2'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_city">City</label></th>
                                    <td><input type="text" id="vendor_city" name="vendor[city]" class="regular-text" value="<?php echo esc_attr($record['city'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_state">State</label></th>
                                    <td><input type="text" id="vendor_state" name="vendor[state]" class="regular-text" value="<?php echo esc_attr($record['state'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_postal_code">Postal Code</label></th>
                                    <td><input type="text" id="vendor_postal_code" name="vendor[postal_code]" class="regular-text" value="<?php echo esc_attr($record['postal_code'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_country">Country</label></th>
                                    <td><input type="text" id="vendor_country" name="vendor[country]" class="regular-text" maxlength="2" value="<?php echo esc_attr($record['country'] ?? 'US'); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_phone">Phone</label></th>
                                    <td><input type="text" id="vendor_phone" name="vendor[phone]" class="regular-text" value="<?php echo esc_attr($record['phone'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_email">Email</label></th>
                                    <td><input type="email" id="vendor_email" name="vendor[email]" class="regular-text" value="<?php echo esc_attr($record['email'] ?? ''); ?>"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="vendor_image_id">Select Image</label></th>
                                    <td>
                                        <input type="hidden" id="vendor_image_id" name="vendor[image_id]" value="<?php echo esc_attr($record['image_id'] ?? 0); ?>">

                                        <div id="ssb-vendor-image-preview" style="min-height: 120px; margin-bottom: 12px;">
                                            <?php
                                            $vendor_image_id = absint($record['image_id'] ?? 0);
                                            $vendor_image_url = $vendor_image_id ? wp_get_attachment_image_url($vendor_image_id, 'medium') : '';
                                            if ($vendor_image_url) :
                                            ?>
                                                <img src="<?php echo esc_url($vendor_image_url); ?>" style="max-width:100%; height:auto; border:1px solid #dcdcde;" />
                                            <?php endif; ?>
                                        </div>

                                        <button type="button" class="button" id="ssb-vendor-image-select">Select Image</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <?php submit_button($editing ? 'Save Vendor' : 'Add New Vendor'); ?>
                    </form>
                </div>

                <div>
                    <table class="widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Company Name</th>
                                <th>Contact</th>
                                <th>City</th>
                                <th>State</th>
                                <th style="width:90px;">Active</th>
                                <th style="width:140px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($rows)) : ?>
                                <tr>
                                    <td colspan="6">No vendors found.</td>
                                </tr>
                            <?php else : ?>
                                <?php foreach ($rows as $row) : ?>
                                    <tr>
                                        <td><?php echo esc_html($row['company_name'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['contact'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['city'] ?? ''); ?></td>
                                        <td><?php echo esc_html($row['state'] ?? ''); ?></td>
                                        <td>
                                            <?php
                                            echo self::render_row_action_link(
                                                'ssb_toggle_vendor_active',
                                                (!empty($row['active']) && $row['active'] === '1') ? 'Active' : 'Inactive',
                                                array('code' => $row['code']),
                                                (!empty($row['active']) && $row['active'] === '1') ? 'button-link' : 'button-link-delete'
                                            );
                                            ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo esc_url(self::get_admin_page_url('ssb-vendors', array('edit' => $row['code']))); ?>">Edit</a>
                                            |
                                            <?php
                                            echo self::render_row_action_link(
                                                'ssb_delete_vendor',
                                                'Delete',
                                                array('code' => $row['code']),
                                                'submitdelete'
                                            );
                                            ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

        /**
         * Register plugin settings.
         *
         * @return void
         */
    public static function register_settings() {
        register_setting(
            'ssb_settings_group',
            'ssb_shipper_origin',
            array(
                'type'              => 'array',
                'sanitize_callback' => array(__CLASS__, 'sanitize_shipper_origin_settings'),
                'default'           => array(),
            )
        );

        register_setting(
            'ssb_settings_group',
            'ssb_enable_rate_cache',
            array(
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default'           => 'yes',
            )
        );

        register_setting('ssb_settings_group', 'ssb_usps_signature_required', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '3.95',
        ));

        register_setting('ssb_settings_group', 'ssb_usps_adult_signature_required', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '9.70',
        ));

        register_setting('ssb_settings_group', 'ssb_usps_insurance', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '0.00',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_signature_required', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '6.25',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_adult_signature_required', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '7.50',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_carbon_neutral', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '0.05',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_saturday_delivery', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '16.00',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_additional_handling', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '14.25',
        ));

        register_setting('ssb_settings_group', 'ssb_ups_insurance', array(
            'type'              => 'string',
            'sanitize_callback' => array(__CLASS__, 'sanitize_money_setting'),
            'default'           => '0.00',
        ));

        register_setting(
            'ssb_settings_group',
            'ssb_enable_multipackage_mode',
            array(
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default'           => 'no',
            )
        );

        register_setting('ssb_settings_group', 'ssb_disable_alcohol');
        register_setting('ssb_settings_group', 'ssb_disable_dry_ice');
        register_setting('ssb_settings_group', 'ssb_disable_hazmat');
        register_setting('ssb_settings_group', self::OPTION_WAREHOUSES);
        register_setting('ssb_settings_group', self::OPTION_VENDORS);
        register_setting('ssb_settings_group', self::OPTION_MAIN_WAREHOUSE_LOGO_1);
        register_setting('ssb_settings_group', self::OPTION_MAIN_WAREHOUSE_LOGO_2);
        register_setting('ssb_settings_group', self::OPTION_FULFILLMENT_LANES);
    }

    /**
     * Add Settings link on Plugins screen.
     *
     * @param array $links
     * @return array
     */
    public static function add_plugin_action_links($links) {
        $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=ssb-settings')) . '">Settings</a>';
        array_unshift($links, $settings_link);
        return $links;
    }

    /**
     * Render settings page.
     *
     * @return void
     */
    public static function render_settings_page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $settings = self::get_shipper_settings();
        $adjustments = self::get_rate_adjustment_settings();
        $main_logo_1_id = absint(get_option(self::OPTION_MAIN_WAREHOUSE_LOGO_1, 0));
        $main_logo_2_id = absint(get_option(self::OPTION_MAIN_WAREHOUSE_LOGO_2, 0));
        $main_logo_1_url = $main_logo_1_id ? wp_get_attachment_image_url($main_logo_1_id, 'medium') : '';
        $main_logo_2_url = $main_logo_2_id ? wp_get_attachment_image_url($main_logo_2_id, 'medium') : '';

?>
        <div class="wrap">
            <h1>Shoshin Shippo Bridge</h1>
            <p>Configure the shipper / origin address used for Shippo label creation.</p>

            <form method="post" action="options.php">
                <?php settings_fields('ssb_settings_group'); ?>

                                <h2>Main Warehouse Branding</h2>
                <p class="description">For best results use images 400x200px.</p>

                <div style="display:grid; grid-template-columns: repeat(2, minmax(320px, 400px)); gap: 24px; margin: 16px 0 28px; align-items:start;">
                    <div>
                        <h3 style="margin-top:0;">Image 1</h3>
                        <input type="hidden" id="ssb_main_warehouse_logo_1" name="ssb_main_warehouse_logo_1" value="<?php echo esc_attr($main_logo_1_id); ?>">
                        <div id="ssb-main-warehouse-logo-1-preview" style="min-height: 120px; margin-bottom: 12px;">
                            <?php if ($main_logo_1_url) : ?>
                                <img src="<?php echo esc_url($main_logo_1_url); ?>" style="max-width:100%; height:auto; border:1px solid #dcdcde;" />
                            <?php endif; ?>
                        </div>
                        <button type="button" class="button" id="ssb-main-warehouse-logo-1-select">Select Image</button>
                    </div>

                    <div>
                        <h3 style="margin-top:0;">Image 2</h3>
                        <input type="hidden" id="ssb_main_warehouse_logo_2" name="ssb_main_warehouse_logo_2" value="<?php echo esc_attr($main_logo_2_id); ?>">
                        <div id="ssb-main-warehouse-logo-2-preview" style="min-height: 120px; margin-bottom: 12px;">
                            <?php if ($main_logo_2_url) : ?>
                                <img src="<?php echo esc_url($main_logo_2_url); ?>" style="max-width:100%; height:auto; border:1px solid #dcdcde;" />
                            <?php endif; ?>
                        </div>
                        <button type="button" class="button" id="ssb-main-warehouse-logo-2-select">Select Image</button>
                    </div>
                </div>

                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_name">Sender name</label></th>
                            <td><input name="ssb_shipper_origin[name]" type="text" id="ssb_shipper_origin_name" class="regular-text" value="<?php echo esc_attr($settings['name']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_company">Company</label></th>
                            <td><input name="ssb_shipper_origin[company]" type="text" id="ssb_shipper_origin_company" class="regular-text" value="<?php echo esc_attr($settings['company']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_street1">Street address 1</label></th>
                            <td><input name="ssb_shipper_origin[street1]" type="text" id="ssb_shipper_origin_street1" class="regular-text" value="<?php echo esc_attr($settings['street1']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_street2">Street address 2</label></th>
                            <td><input name="ssb_shipper_origin[street2]" type="text" id="ssb_shipper_origin_street2" class="regular-text" value="<?php echo esc_attr($settings['street2']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_city">City</label></th>
                            <td><input name="ssb_shipper_origin[city]" type="text" id="ssb_shipper_origin_city" class="regular-text" value="<?php echo esc_attr($settings['city']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_state">State / Province</label></th>
                            <td><input name="ssb_shipper_origin[state]" type="text" id="ssb_shipper_origin_state" class="regular-text" value="<?php echo esc_attr($settings['state']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_zip">ZIP / Postal code</label></th>
                            <td><input name="ssb_shipper_origin[zip]" type="text" id="ssb_shipper_origin_zip" class="regular-text" value="<?php echo esc_attr($settings['zip']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_country">Country code</label></th>
                            <td>
                                <input name="ssb_shipper_origin[country]" type="text" id="ssb_shipper_origin_country" class="regular-text" maxlength="2" value="<?php echo esc_attr($settings['country']); ?>">
                                <p class="description">Use a 2-letter ISO country code, such as US.</p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_phone">Phone</label></th>
                            <td>
                                <input name="ssb_shipper_origin[phone]" type="text" id="ssb_shipper_origin_phone" class="regular-text" value="<?php echo esc_attr($settings['phone']); ?>">
                                <p class="description">For USPS/UPS, enter a real origin phone. Digits-only is preferred.</p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row"><label for="ssb_shipper_origin_email">Email</label></th>
                            <td><input name="ssb_shipper_origin[email]" type="email" id="ssb_shipper_origin_email" class="regular-text" value="<?php echo esc_attr($settings['email']); ?>"></td>
                        </tr>

                        <tr>
                            <th scope="row">Admin Rate Cache</th>
                            <td>
                                <label for="ssb_enable_rate_cache">
                                    <input type="checkbox"
                                        id="ssb_enable_rate_cache"
                                        name="ssb_enable_rate_cache"
                                        value="yes"
                                        <?php checked(get_option('ssb_enable_rate_cache', 'yes'), 'yes'); ?>>
                                    Enable 60-second caching for admin "Fetch Rates" requests
                                </label>
                                <p class="description">
                                    Reduces UPS throttling during admin use. Disable for debugging live rate behavior.
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">WooCommerce Multi-Package Mode</th>
                            <td>
                                <label for="ssb_enable_multipackage_mode">
                                    <input type="checkbox"
                                        id="ssb_enable_multipackage_mode"
                                        name="ssb_enable_multipackage_mode"
                                        value="yes"
                                        <?php checked(get_option('ssb_enable_multipackage_mode', 'no'), 'yes'); ?>>
                                    Enable Multi-Package Mode
                                </label>
                                <p class="description">
                                    When enabled, the plugin will use multi-package shipping logic for storefront package splitting and future warehouse multi-piece fulfillment behavior. Leave disabled to preserve the current single-package baseline.
                                </p>
                            </td>
                        </tr>

                        <tr>
                            <th scope="row">Shipment Option Controls</th>
                            <td>
                                <label>
                                    <input type="checkbox"
                                        name="ssb_disable_alcohol"
                                        value="1"
                                        <?php checked(get_option('ssb_disable_alcohol', '0'), '1'); ?>>
                                    Disable Alcohol
                                </label>
                                <br>

                                <label>
                                    <input type="checkbox"
                                        name="ssb_disable_dry_ice"
                                        value="1"
                                        <?php checked(get_option('ssb_disable_dry_ice', '0'), '1'); ?>>
                                    Disable Dry Ice
                                </label>
                                <br>

                                <label>
                                    <input type="checkbox"
                                        name="ssb_disable_hazmat"
                                        value="1"
                                        <?php checked(get_option('ssb_disable_hazmat', '0'), '1'); ?>>
                                    Disable Hazmat
                                </label>

                                <p class="description">
                                    These options are globally disabled and cannot be selected during label creation.
                                </p>
                            </td>
                        </tr>

                    </tbody>
                </table>

<hr style="margin:24px 0;">

<h2>Admin Rate Adjustment Settings</h2>
<p>These values control the optional add-on amounts shown on admin carrier cards and will be used for internal adjusted-rate calculations.</p>

<table class="form-table" role="presentation">
    <tbody>
        <tr>
            <th scope="row" colspan="2"><h3 style="margin:0;">USPS</h3></th>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_usps_signature_required">Signature Required</label></th>
            <td>
                <input name="ssb_usps_signature_required" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_usps_signature_required" class="regular-text" value="<?php echo esc_attr($adjustments['usps_signature_required']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_usps_adult_signature_required">Adult Signature Required</label></th>
            <td>
                <input name="ssb_usps_adult_signature_required" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_usps_adult_signature_required" class="regular-text" value="<?php echo esc_attr($adjustments['usps_adult_signature_required']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_usps_insurance">Insurance</label></th>
            <td>
                <input name="ssb_usps_insurance" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_usps_insurance" class="regular-text" value="<?php echo esc_attr($adjustments['usps_insurance']); ?>">
                <p class="description">Charged per additional $100 of declared value above the service’s included insurance. Rounded up to the next $100.</p>
            </td>
        </tr>

        <tr>
            <th scope="row" colspan="2"><h3 style="margin:16px 0 0;">UPS</h3></th>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_signature_required">Signature Required</label></th>
            <td>
                <input name="ssb_ups_signature_required" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_signature_required" class="regular-text" value="<?php echo esc_attr($adjustments['ups_signature_required']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_adult_signature_required">Adult Signature Required</label></th>
            <td>
                <input name="ssb_ups_adult_signature_required" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_adult_signature_required" class="regular-text" value="<?php echo esc_attr($adjustments['ups_adult_signature_required']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_carbon_neutral">Carbon Neutral</label></th>
            <td>
                <input name="ssb_ups_carbon_neutral" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_carbon_neutral" class="regular-text" value="<?php echo esc_attr($adjustments['ups_carbon_neutral']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_saturday_delivery">Saturday Delivery</label></th>
            <td>
                <input name="ssb_ups_saturday_delivery" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_saturday_delivery" class="regular-text" value="<?php echo esc_attr($adjustments['ups_saturday_delivery']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_additional_handling">Additional Handling</label></th>
            <td>
                <input name="ssb_ups_additional_handling" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_additional_handling" class="regular-text" value="<?php echo esc_attr($adjustments['ups_additional_handling']); ?>">
            </td>
        </tr>

        <tr>
            <th scope="row"><label for="ssb_ups_insurance">Insurance</label></th>
            <td>
                <input name="ssb_ups_insurance" type="number" step="0.01" min="0" inputmode="decimal" id="ssb_ups_insurance" class="regular-text" value="<?php echo esc_attr($adjustments['ups_insurance']); ?>">
                <p class="description">Charged per additional $100 of declared value above the service’s included insurance. Rounded up to the next $100.</p>
            </td>
        </tr>
    </tbody>
</table>

<?php submit_button('Save Settings'); ?>
            </form>
        </div>
        <?php
    }

        protected static function get_rate_adjustment_settings() {
            return array(
                'usps_signature_required'       => self::normalize_money_setting(get_option('ssb_usps_signature_required', '3.95')),
                'usps_adult_signature_required' => self::normalize_money_setting(get_option('ssb_usps_adult_signature_required', '9.70')),
                'usps_insurance'                => self::normalize_money_setting(get_option('ssb_usps_insurance', '0.00')),
                'ups_signature_required'        => self::normalize_money_setting(get_option('ssb_ups_signature_required', '6.25')),
                'ups_adult_signature_required'  => self::normalize_money_setting(get_option('ssb_ups_adult_signature_required', '7.50')),
                'ups_carbon_neutral'            => self::normalize_money_setting(get_option('ssb_ups_carbon_neutral', '0.05')),
                'ups_saturday_delivery'         => self::normalize_money_setting(get_option('ssb_ups_saturday_delivery', '16.00')),
                'ups_additional_handling'       => self::normalize_money_setting(get_option('ssb_ups_additional_handling', '14.25')),
                'ups_insurance'                 => self::normalize_money_setting(get_option('ssb_ups_insurance', '0.00')),
            );
        }

    /**
     * Return shipper settings, falling back to Woo/store values.
     *
     * @return array
     */
    protected static function get_shipper_settings() {
        $saved = get_option('ssb_shipper_origin', array());
        $saved = is_array($saved) ? $saved : array();

        $country_state = (string) get_option('woocommerce_default_country', '');
        $country = '';
        $state   = '';

        if ($country_state !== '') {
            $parts   = explode(':', $country_state);
            $country = isset($parts[0]) ? strtoupper(trim((string) $parts[0])) : '';
            $state   = isset($parts[1]) ? strtoupper(trim((string) $parts[1])) : '';
        }

        $store_company = (string) get_option('woocommerce_store_company', '');
        if ($store_company === '') {
            $store_company = (string) get_option('woocommerce_store_name', '');
        }
        if ($store_company === '') {
            $store_company = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        }

        $defaults = array(
            'name'    => 'Shipping Department',
            'company' => $store_company,
            'street1' => (string) get_option('woocommerce_store_address', ''),
            'street2' => (string) get_option('woocommerce_store_address_2', ''),
            'city'    => (string) get_option('woocommerce_store_city', ''),
            'state'   => $state,
            'zip'     => (string) get_option('woocommerce_store_postcode', ''),
            'country' => $country,
            'phone'   => (string) get_option('woocommerce_store_phone', ''),
            'email'   => (string) get_option('admin_email', ''),
        );

        if ($defaults['email'] === '') {
            $defaults['email'] = (string) get_option('woocommerce_email_from_address', '');
        }

        return wp_parse_args($saved, $defaults);
    }

        public static function sanitize_money_setting($value) {
            return self::normalize_money_setting($value);
        }

    /**
     * Sanitize shipper origin settings.
     *
     * @param mixed $input
     * @return array
     */
    public static function sanitize_shipper_origin_settings($input) {
        $input = is_array($input) ? $input : array();

        $country = isset($input['country']) ? strtoupper(trim((string) $input['country'])) : '';

        return array(
            'name'    => isset($input['name']) ? sanitize_text_field($input['name']) : '',
            'company' => isset($input['company']) ? sanitize_text_field($input['company']) : '',
            'street1' => isset($input['street1']) ? sanitize_text_field($input['street1']) : '',
            'street2' => isset($input['street2']) ? sanitize_text_field($input['street2']) : '',
            'city'    => isset($input['city']) ? sanitize_text_field($input['city']) : '',
            'state'   => isset($input['state']) ? sanitize_text_field($input['state']) : '',
            'zip'     => isset($input['zip']) ? sanitize_text_field($input['zip']) : '',
            'country' => preg_replace('/[^A-Z]/', '', $country),
            'phone'   => isset($input['phone']) ? sanitize_text_field($input['phone']) : '',
            'email'   => isset($input['email']) ? sanitize_email($input['email']) : '',
        );
    }

        public static function is_multipackage_mode_enabled() {
        return get_option('ssb_enable_multipackage_mode', 'no') === 'yes';
    }

    /**
     * Lightweight diagnostic payload for admin/debugging.
     *
     * @return array
     */
    public static function get_debug_context() {
        return array(
            'mode'        => self::is_test_mode() ? 'test' : 'live',
            'has_token'   => self::get_shippo_token() !== '',
            'origin'      => self::get_origin_address(),
        );
    }

    /**
     * Attempt to detect current Shippo mode from installed Shippo plugin options.
     *
     * This is intentionally defensive because third-party plugin option keys can vary.
     *
     * @return bool|null
     */
    protected static function detect_shippo_mode_from_existing_plugin() {
        $candidates = self::get_existing_shippo_option_candidates();

        foreach ($candidates as $option_name => $value) {
            if (!is_array($value)) {
                continue;
            }

            $flat = self::flatten_array_keys($value);

            $truthy_keys = array(
                'sandbox',
                'test_mode',
                'sandbox_mode',
                'is_test_mode',
                'enable_test_mode',
                'shippo_test_mode',
                'shippo_mode',
                'shippo_environment',
            );

            foreach ($truthy_keys as $key) {
                if (!array_key_exists($key, $flat)) {
                    continue;
                }

                $raw = $flat[$key];

                if (is_bool($raw)) {
                    return $raw;
                }

                $raw = strtolower(trim((string) $raw));

                if (in_array($raw, array('test', 'sandbox', 'yes', '1', 'true'), true)) {
                    return true;
                }

                if (in_array($raw, array('live', 'production', 'no', '0', 'false'), true)) {
                    return false;
                }
            }
        }

        return null;
    }

    /**
     * Attempt to detect live/test API tokens from installed Shippo plugin options.
     *
     * @return array{live:string,test:string}
     */
    protected static function detect_shippo_tokens_from_existing_plugin() {
        $result = array(
            'live' => '',
            'test' => '',
        );

        $candidates = self::get_existing_shippo_option_candidates();

        foreach ($candidates as $option_name => $value) {
            if (!is_array($value)) {
                continue;
            }

            $flat = self::flatten_array_keys($value);

            foreach ($flat as $key => $raw) {
                if (!is_scalar($raw)) {
                    continue;
                }

                $key_lc = strtolower((string) $key);
                $val    = trim((string) $raw);

                if ($val === '') {
                    continue;
                }

                if (
                    $result['test'] === '' &&
                    (
                        strpos($key_lc, 'testapitoken') !== false ||
                        strpos($key_lc, 'test_api_key') !== false ||
                        strpos($key_lc, 'test_token') !== false ||
                        strpos($key_lc, 'sandbox_api_key') !== false ||
                        strpos($key_lc, 'sandbox_token') !== false
                    )
                ) {
                    $result['test'] = $val;
                    continue;
                }

                if (
                    $result['live'] === '' &&
                    (
                        strpos($key_lc, 'liveapitoken') !== false ||
                        strpos($key_lc, 'live_api_key') !== false ||
                        strpos($key_lc, 'live_token') !== false ||
                        (
                            strpos($key_lc, 'shippo') !== false &&
                            (
                                strpos($key_lc, 'api_key') !== false ||
                                strpos($key_lc, 'api_token') !== false ||
                                strpos($key_lc, 'token') !== false
                            )
                        )
                    )
                ) {
                    $result['live'] = $val;
                    continue;
                }
            }
        }

        return $result;
    }

    /**
     * Gather likely Shippo plugin option records from wp_options.
     *
     * @return array
     */
    protected static function get_existing_shippo_option_candidates() {
        global $wpdb;

        $results = array();

        $like_patterns = array(
            'shippo',
            'wc_shippo',
            'one_team_shippo',
            'oneteamsoft',
        );

        foreach ($like_patterns as $pattern) {
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    "
                    SELECT option_name, option_value
                    FROM {$wpdb->options}
                    WHERE option_name LIKE %s
                    ",
                    '%' . $wpdb->esc_like($pattern) . '%'
                ),
                ARRAY_A
            );

            if (empty($rows)) {
                continue;
            }

            foreach ($rows as $row) {
                $name  = isset($row['option_name']) ? (string) $row['option_name'] : '';
                $value = isset($row['option_value']) ? maybe_unserialize($row['option_value']) : null;

                if ($name === '' || isset($results[$name])) {
                    continue;
                }

                $results[$name] = $value;
            }
        }

        return $results;
    }

    /**
     * Flatten nested option arrays into key => scalar value map.
     *
     * @param array  $array
     * @param string $prefix
     * @return array
     */
    protected static function flatten_array_keys(array $array, $prefix = '') {
        $flat = array();

        foreach ($array as $key => $value) {
            $key = (string) $key;
            $composed = $prefix === '' ? $key : $prefix . '.' . $key;

            if (is_array($value)) {
                $flat = array_merge($flat, self::flatten_array_keys($value, $composed));
                continue;
            }

            $flat[$key] = $value;
            $flat[$composed] = $value;
        }

        return $flat;
    }
}