<?php
if (!defined('ABSPATH')) {
    exit;
}

class SSB_Frontend {

    public static function init() {
        add_action('woocommerce_order_details_after_order_table', array(__CLASS__, 'render_tracking_block'), 20);
    }

    /**
     * Render customer-facing tracking block on the order page.
     *
     * @param WC_Order $order
     * @return void
     */
    public static function render_tracking_block($order) {
        if (!$order || !is_a($order, 'WC_Order')) {
            return;
        }

        $order_id = $order->get_id();

        $tracking_number        = (string) get_post_meta($order_id, '_shoshin_shippo_tracking_number', true);
        $tracking_status        = (string) get_post_meta($order_id, '_shoshin_shippo_tracking_status', true);
        $carrier                = (string) get_post_meta($order_id, '_shoshin_shippo_carrier', true);
        $service                = (string) get_post_meta($order_id, '_shoshin_shippo_service', true);
        $label_url              = (string) get_post_meta($order_id, '_shoshin_shippo_label_url', true);
        $tracking_url           = (string) get_post_meta($order_id, '_shoshin_shippo_tracking_url', true);

        $return_tracking_number = (string) get_post_meta($order_id, '_shoshin_shippo_return_tracking_number', true);
        $return_tracking_status = (string) get_post_meta($order_id, '_shoshin_shippo_return_tracking_status', true);
        $return_carrier         = (string) get_post_meta($order_id, '_shoshin_shippo_return_carrier', true);
        $return_service         = (string) get_post_meta($order_id, '_shoshin_shippo_return_service', true);
        $return_label_url       = (string) get_post_meta($order_id, '_shoshin_shippo_return_label_url', true);
        $return_tracking_url    = (string) get_post_meta($order_id, '_shoshin_shippo_return_tracking_url', true);

        $has_outbound = ($tracking_number !== '' || $label_url !== '');
        $has_return   = ($return_tracking_number !== '' || $return_label_url !== '');

        if (!$has_outbound && !$has_return) {
            return;
        }

        echo '<section class="woocommerce-order-details ssb-order-tracking">';
        echo '<h2 class="woocommerce-order-details__title">Shipment Tracking</h2>';
        echo '<div class="ssb-order-tracking__content">';

        if ($has_outbound) {
            echo '<div class="ssb-order-tracking__group ssb-order-tracking__group--outbound">';

            if ($carrier) {
                echo '<p><strong>Carrier:</strong> ' . esc_html($carrier) . '</p>';
            }

            if ($service) {
                echo '<p><strong>Service:</strong> ' . esc_html($service) . '</p>';
            }

            if ($tracking_number) {
                if (!$tracking_url) {
                    if ($carrier && strtolower($carrier) === 'usps') {
                        $tracking_url = 'https://tools.usps.com/go/TrackConfirmAction?tLabels=' . urlencode($tracking_number);
                    } else {
                        $tracking_url = 'https://track.goshippo.com/track/' . urlencode($tracking_number);
                    }
                }

                echo '<p><strong>Tracking Number:</strong> ';

                if ($tracking_url) {
                    echo '<a href="' . esc_url($tracking_url) . '" target="_blank" rel="noopener noreferrer">'
                        . esc_html($tracking_number)
                        . '</a>';
                } else {
                    echo esc_html($tracking_number);
                }

                echo '</p>';
            }

            if ($tracking_status) {
                echo '<p><strong>Status:</strong> ' . esc_html($tracking_status) . '</p>';
            }

            if ($label_url) {
                echo '<p><a class="button" href="' . esc_url($label_url) . '" target="_blank" rel="noopener noreferrer">View Shipping Label</a></p>';
            }

            echo '</div>';
        }

        if ($has_return) {
            if ($has_outbound) {
                echo '<hr>';
            }

            echo '<div class="ssb-order-tracking__group ssb-order-tracking__group--return">';
            echo '<p><strong>Return Label:</strong> Active</p>';

            if ($return_carrier) {
                echo '<p><strong>Return Carrier:</strong> ' . esc_html($return_carrier) . '</p>';
            }

            if ($return_service) {
                echo '<p><strong>Return Service:</strong> ' . esc_html($return_service) . '</p>';
            }

            if ($return_tracking_number) {
                echo '<p><strong>Return Tracking Number:</strong> ';

                if ($return_tracking_url) {
                    echo '<a href="' . esc_url($return_tracking_url) . '" target="_blank" rel="noopener noreferrer">'
                        . esc_html($return_tracking_number)
                        . '</a>';
                } else {
                    echo esc_html($return_tracking_number);
                }

                echo '</p>';
            }

            if ($return_tracking_status) {
                echo '<p><strong>Return Status:</strong> ' . esc_html($return_tracking_status) . '</p>';
            }

            if ($return_label_url) {
                echo '<p><a class="button" href="' . esc_url($return_label_url) . '" target="_blank" rel="noopener noreferrer">View Return Label</a></p>';
            }

            echo '</div>';
        }

        echo '</div>';
        echo '</section>';
    }
}